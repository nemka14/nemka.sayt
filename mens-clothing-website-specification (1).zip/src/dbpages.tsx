import { useEffect, useState } from "react";
import type { User, Order, Review, FormSubmission } from "./db";
import { Btn, Section, Icon } from "./components";
import type { Page } from "./components";
import * as Repo from "./repository";
import { clearTelegramChatCache, getTelegramStatus, sendTelegramTestMessage } from "./telegram";

export function LoginPage({ onLogin, showToast }: {
  navigate: (p: Page) => void;
  onLogin: (u: User) => void;
  showToast: (msg: string) => void;
}) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (mode === "register") {
        if (!name || !email || !phone || !password) {
          setError("Заполните все поля");
          setLoading(false);
          return;
        }
        const result = await Repo.registerUser(name, email, phone, password);
        if (typeof result === "string") {
          setError(result);
          setLoading(false);
          return;
        }
        onLogin(result);
        showToast("Регистрация успешна! Пользователь сохранён.");
      } else {
        if (!email || !password) {
          setError("Введите email и пароль");
          setLoading(false);
          return;
        }
        const result = await Repo.loginUser(email, password);
        if (typeof result === "string") {
          setError(result);
          setLoading(false);
          return;
        }
        onLogin(result);
        showToast("Вход выполнен успешно");
      }
    } catch {
      setError("Не удалось получить данные. Проверь Supabase или попробуй ещё раз.");
    }
    setLoading(false);
  };

  return (
    <Section eyebrow="Аккаунт" title={mode === "login" ? "Вход" : "Регистрация"}>
      <div className="max-w-md mx-auto slide-up">
        <div className="flex gap-2 mb-8">
          <button onClick={() => setMode("login")} className={`flex-1 py-3 text-xs uppercase tracking-[0.2em] border transition ${mode === "login" ? "bg-ink text-paper border-ink" : "border-ink/30 hover:border-ink"}`}>Вход</button>
          <button onClick={() => setMode("register")} className={`flex-1 py-3 text-xs uppercase tracking-[0.2em] border transition ${mode === "register" ? "bg-ink text-paper border-ink" : "border-ink/30 hover:border-ink"}`}>Регистрация</button>
        </div>
        {error && <div className="bg-red-500/20 border border-red-500/50 text-red-400 px-4 py-3 mb-6 text-sm rounded">{error}</div>}
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "register" && (
            <>
              <label className="block"><span className="text-xs uppercase tracking-[0.2em] text-ash block mb-2">Имя</span><input value={name} onChange={e => setName(e.target.value)} required className="w-full bg-cream border border-ink/20 px-4 py-3 outline-none focus:border-accent transition" /></label>
              <label className="block"><span className="text-xs uppercase tracking-[0.2em] text-ash block mb-2">Телефон</span><input value={phone} onChange={e => setPhone(e.target.value)} type="tel" required className="w-full bg-cream border border-ink/20 px-4 py-3 outline-none focus:border-accent transition" /></label>
            </>
          )}
          <label className="block"><span className="text-xs uppercase tracking-[0.2em] text-ash block mb-2">Email</span><input value={email} onChange={e => setEmail(e.target.value)} type="email" required className="w-full bg-cream border border-ink/20 px-4 py-3 outline-none focus:border-accent transition" /></label>
          <label className="block"><span className="text-xs uppercase tracking-[0.2em] text-ash block mb-2">Пароль</span><input value={password} onChange={e => setPassword(e.target.value)} type="password" required minLength={4} className="w-full bg-cream border border-ink/20 px-4 py-3 outline-none focus:border-accent transition" /></label>
          <Btn full type="submit">{loading ? "Загрузка..." : mode === "login" ? "Войти" : "Зарегистрироваться"}</Btn>
        </form>
      </div>
    </Section>
  );
}

export function AccountPage({ user, navigate, onLogout }: {
  user: User | null;
  navigate: (p: Page) => void;
  onLogout: () => void;
  showToast: (msg: string) => void;
}) {
  const [tab, setTab] = useState<"profile" | "orders" | "reviews">("profile");
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      setLoading(true);
      const [userOrders, allReviews] = await Promise.all([
        Repo.getOrdersByUser(user.id),
        Repo.getAllReviews(),
      ]);
      setOrders(userOrders);
      setReviews(allReviews.filter(r => r.userId === user.id));
      setLoading(false);
    };
    void load();
  }, [user]);

  if (!user) {
    return (
      <Section eyebrow="Аккаунт" title="Войдите в аккаунт">
        <div className="text-center py-16 slide-up">
          <p className="text-ash mb-6">Войдите или зарегистрируйтесь чтобы видеть историю заказов и управлять профилем.</p>
          <Btn onClick={() => navigate({ name: "login" })}>Войти / Регистрация</Btn>
        </div>
      </Section>
    );
  }

  const statusLabels: Record<string, string> = {
    new: "🆕 Новый", processing: "⏳ В обработке", shipped: "📦 Отправлен", delivered: "✅ Доставлен", cancelled: "❌ Отменён",
  };

  return (
    <Section eyebrow="Личный кабинет" title={`Привет, ${user.name}!`}>
      <div className="slide-up">
        <div className="flex flex-wrap gap-2 mb-8">
          {(["profile", "orders", "reviews"] as const).map(t => (
            <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-xs uppercase tracking-[0.2em] border rounded-full transition ${tab === t ? "bg-ink text-paper border-ink glow-effect" : "border-ink/30 hover:border-ink"}`}>
              {t === "profile" ? "Профиль" : t === "orders" ? `Заказы (${orders.length})` : `Отзывы (${reviews.length})`}
            </button>
          ))}
          <button onClick={onLogout} className="px-4 py-2 text-xs uppercase tracking-[0.2em] border border-red-500/50 text-red-400 rounded-full hover:bg-red-500/20 transition ml-auto">Выйти</button>
        </div>

        {loading ? <p className="text-ash py-12 text-center">Загружаем данные из базы...</p> : (
          <>
            {tab === "profile" && (
              <div className="grid md:grid-cols-2 gap-8 card-animate">
                <div className="bg-cream p-6 rounded-lg border border-ink/10">
                  <p className="text-xs uppercase tracking-[0.25em] text-ash mb-4">Данные</p>
                  <div className="space-y-3 text-sm">
                    <div><span className="text-ash">Имя:</span> <span className="font-medium">{user.name}</span></div>
                    <div><span className="text-ash">Email:</span> <span className="font-medium">{user.email}</span></div>
                    <div><span className="text-ash">Телефон:</span> <span className="font-medium">{user.phone}</span></div>
                    <div><span className="text-ash">Зарегистрирован:</span> <span className="font-medium">{new Date(user.createdAt).toLocaleDateString("ru")}</span></div>
                  </div>
                </div>
                <div className="bg-cream p-6 rounded-lg border border-ink/10">
                  <p className="text-xs uppercase tracking-[0.25em] text-ash mb-4">Статистика</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-paper rounded"><div className="text-2xl font-bold text-accent">{orders.length}</div><div className="text-xs text-ash">Заказов</div></div>
                    <div className="text-center p-4 bg-paper rounded"><div className="text-2xl font-bold text-accent-2">{orders.reduce((a, o) => a + o.total, 0).toLocaleString("ru")} ₽</div><div className="text-xs text-ash">Потрачено</div></div>
                    <div className="text-center p-4 bg-paper rounded"><div className="text-2xl font-bold text-accent">{reviews.length}</div><div className="text-xs text-ash">Отзывов</div></div>
                    <div className="text-center p-4 bg-paper rounded"><div className="text-2xl font-bold text-accent-2">{orders.filter(o => o.status === "delivered").length}</div><div className="text-xs text-ash">Доставлено</div></div>
                  </div>
                </div>
              </div>
            )}
            {tab === "orders" && (
              <div className="space-y-4">
                {orders.length === 0 && <p className="text-ash text-center py-12">У вас пока нет заказов.</p>}
                {orders.map((o, i) => (
                  <div key={o.id} className="bg-cream border border-ink/10 p-5 rounded-lg card-animate" style={{animationDelay: `${i * 0.1}s`}}>
                    <div className="flex items-center justify-between mb-3"><span className="font-mono text-sm font-medium text-accent">{o.id}</span><span className="text-xs bg-paper px-3 py-1 rounded-full">{statusLabels[o.status]}</span></div>
                    <div className="text-xs text-ash mb-2">{new Date(o.createdAt).toLocaleString("ru")}</div>
                    <div className="space-y-1 mb-3">{o.items.map((item, j) => <div key={j} className="flex justify-between text-sm"><span>{item.name} · {item.size} × {item.qty}</span><span>{(item.price * item.qty).toLocaleString("ru")} ₽</span></div>)}</div>
                    <div className="text-right font-semibold text-accent-2">{o.total.toLocaleString("ru")} ₽</div>
                  </div>
                ))}
              </div>
            )}
            {tab === "reviews" && (
              <div className="space-y-4">
                {reviews.length === 0 && <p className="text-ash text-center py-12">Вы пока не оставляли отзывов.</p>}
                {reviews.map((r, i) => (
                  <div key={r.id} className="bg-cream border border-ink/10 p-5 rounded-lg card-animate" style={{animationDelay: `${i * 0.1}s`}}>
                    <div className="flex items-center gap-1 text-accent-2 mb-2">{Array.from({ length: r.rating }).map((_, j) => <Icon key={j} name="star" size={14} />)}</div>
                    <p className="text-sm mb-2">{r.text}</p>
                    <div className="text-xs text-ash">{r.productName} · {new Date(r.createdAt).toLocaleDateString("ru")}</div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </Section>
  );
}

export function AdminPage({ showToast }: { navigate: (p: Page) => void; showToast: (msg: string) => void }) {
  const [tab, setTab] = useState<"stats" | "orders" | "users" | "reviews" | "forms">("stats");
  const [stats, setStats] = useState({ users: 0, orders: 0, reviews: 0, forms: 0, totalRevenue: 0, newOrders: 0, processingOrders: 0, shippedOrders: 0, deliveredOrders: 0 });
  const [orders, setOrders] = useState<Order[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [forms, setForms] = useState<FormSubmission[]>([]);
  const [backend, setBackend] = useState<{ mode: "supabase" | "local"; ok: boolean; message: string }>({ mode: "local", ok: false, message: "Проверка подключения..." });
  const [telegram, setTelegram] = useState<{ ok: boolean; message: string; chatId?: string | null }>({ ok: false, message: "Проверка Telegram..." });
  const [loading, setLoading] = useState(true);

  const loadAll = async () => {
    setLoading(true);
    const [statsData, ordersData, usersData, reviewsData, formsData, backendStatus, telegramStatus] = await Promise.all([
      Repo.getDbStats(), Repo.getAllOrders(), Repo.getAllUsers(), Repo.getAllReviews(), Repo.getAllFormSubmissions(), Repo.getBackendStatus(), getTelegramStatus(),
    ]);
    setStats(statsData as any);
    setOrders(ordersData);
    setUsers(usersData);
    setReviews(reviewsData);
    setForms(formsData);
    setBackend(backendStatus);
    setTelegram(telegramStatus);
    setLoading(false);
  };

  const handleSync = async () => {
    const result = await Repo.syncLocalDataToSupabase();
    showToast(result.message);
    await loadAll();
  };

  useEffect(() => { void loadAll(); }, []);

  const statusLabels: Record<string, string> = {
    new: "🆕 Новый", processing: "⏳ Обработка", shipped: "📦 Отправлен", delivered: "✅ Доставлен", cancelled: "❌ Отменён",
  };
  const formLabels: Record<string, string> = {
    feedback: "Обратная связь", "size-help": "Подбор размера", "style-consult": "Стилист", wholesale: "Опт", "quick-order": "Быстрый заказ", gift: "Подарок", notify: "Уведомление", subscribe: "Подписка", contact: "Контакт",
  };

  const changeStatus = async (orderId: string, status: Order["status"]) => {
    const ok = await Repo.updateOrderStatus(orderId, status);
    if (ok) {
      showToast(`Статус заказа ${orderId} изменён`);
      void loadAll();
    }
  };

  return (
    <Section eyebrow="Панель управления" title="Админ-панель NEMKA">
      <div className="slide-up">
        <div className={`mb-4 rounded-xl border px-4 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3 ${backend.ok ? "border-green-500/40 bg-green-500/10" : "border-yellow-500/40 bg-yellow-500/10"}`}>
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-ash mb-1">Статус базы данных</div>
            <div className="text-sm font-medium">{backend.ok ? "🟢 Supabase активен" : "🟡 Используется localStorage"}</div>
            <div className="text-xs text-ash mt-1">{backend.message}</div>
          </div>
          <button onClick={() => void handleSync()} className="px-4 py-2 text-xs uppercase tracking-[0.2em] border border-ink/20 rounded-full hover:border-ink transition self-start md:self-auto">
            Синхронизировать local → supabase
          </button>
        </div>

        <div className={`mb-6 rounded-xl border px-4 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3 ${telegram.ok ? "border-sky-500/40 bg-sky-500/10" : "border-orange-500/40 bg-orange-500/10"}`}>
          <div>
            <div className="text-xs uppercase tracking-[0.2em] text-ash mb-1">Статус Telegram</div>
            <div className="text-sm font-medium">{telegram.ok ? "🟢 Telegram уведомления активны" : "🟡 Telegram требует настройки"}</div>
            <div className="text-xs text-ash mt-1">{telegram.message}</div>
            {telegram.chatId && <div className="text-xs text-accent mt-1">chat_id: {telegram.chatId}</div>}
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => void sendTelegramTestMessage().then(ok => showToast(ok ? "Тестовое сообщение отправлено в Telegram" : "Telegram не отправил сообщение"))} className="px-4 py-2 text-xs uppercase tracking-[0.2em] border border-ink/20 rounded-full hover:border-ink transition">
              Отправить тест
            </button>
            <button onClick={() => { clearTelegramChatCache(); showToast("Кэш chat_id очищен. Напиши боту ещё раз и обнови админку."); void loadAll(); }} className="px-4 py-2 text-xs uppercase tracking-[0.2em] border border-ink/20 rounded-full hover:border-ink transition">
              Сбросить chat_id
            </button>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mb-8 overflow-x-auto no-scrollbar">
          {(["stats", "orders", "users", "reviews", "forms"] as const).map(t => (
            <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 text-xs uppercase tracking-[0.18em] border rounded-full transition shrink-0 ${tab === t ? "bg-accent text-paper border-accent" : "border-ink/30 hover:border-ink"}`}>
              {t === "stats" ? "📊 Сводка" : t === "orders" ? `📦 Заказы (${orders.length})` : t === "users" ? `👥 Пользователи (${users.length})` : t === "reviews" ? `⭐ Отзывы (${reviews.length})` : `📋 Заявки (${forms.length})`}
            </button>
          ))}
        </div>
        {loading ? <p className="text-ash text-center py-12">Загружаем данные из Supabase...</p> : (
          <>
            {tab === "stats" && <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[
              { label: "Пользователей", value: stats.users, icon: "👥", color: "text-accent" },
              { label: "Всего заказов", value: stats.orders, icon: "📦", color: "text-accent-2" },
              { label: "Выручка", value: `${stats.totalRevenue.toLocaleString("ru")} ₽`, icon: "💰", color: "text-accent" },
              { label: "Отзывов", value: stats.reviews, icon: "⭐", color: "text-accent-2" },
              { label: "Новых заказов", value: stats.newOrders, icon: "🆕", color: "text-accent" },
              { label: "В обработке", value: stats.processingOrders, icon: "⏳", color: "text-accent-2" },
              { label: "Отправлено", value: stats.shippedOrders, icon: "🚚", color: "text-accent" },
              { label: "Доставлено", value: stats.deliveredOrders, icon: "✅", color: "text-accent-2" },
            ].map((s, i) => <div key={i} className="bg-cream border border-ink/10 p-5 rounded-lg text-center card-animate" style={{animationDelay: `${i * 0.05}s`}}><div className="text-2xl mb-1">{s.icon}</div><div className={`text-2xl font-bold ${s.color}`}>{s.value}</div><div className="text-xs text-ash mt-1">{s.label}</div></div>)}</div>}
            {tab === "orders" && <div className="space-y-4 max-h-[70vh] overflow-auto">{orders.length === 0 && <p className="text-ash text-center py-12">Заказов пока нет.</p>}{orders.slice().reverse().map(o => <div key={o.id} className="bg-cream border border-ink/10 p-5 rounded-lg"><div className="flex items-center justify-between mb-2 flex-wrap gap-2"><span className="font-mono text-sm font-medium text-accent">{o.id}</span><span className="text-xs">{statusLabels[o.status]}</span></div><div className="text-xs text-ash mb-2">{o.name} · {o.phone} · {o.email}</div><div className="text-xs text-ash mb-2">{o.city}, {o.address}</div>{o.items.map((item, j) => <div key={j} className="text-sm flex justify-between"><span>{item.name} ({item.size}, {item.color}) × {item.qty}</span><span>{(item.price * item.qty).toLocaleString("ru")} ₽</span></div>)}<div className="text-right font-semibold text-accent-2 mt-2">{o.total.toLocaleString("ru")} ₽</div><div className="flex flex-wrap gap-2 mt-3 border-t border-ink/10 pt-3">{(["processing", "shipped", "delivered", "cancelled"] as const).map(s => <button key={s} onClick={() => void changeStatus(o.id, s)} className={`text-xs px-3 py-1.5 rounded border transition ${o.status === s ? "bg-accent text-paper border-accent" : "border-ink/20 hover:border-ink"}`}>{statusLabels[s]}</button>)}</div></div>)}</div>}
            {tab === "users" && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm min-w-[900px]">
                  <thead>
                    <tr className="text-left text-xs uppercase tracking-[0.15em] text-ash border-b border-ink/20">
                      <th className="py-3 px-2">ID</th>
                      <th className="py-3 px-2">Имя</th>
                      <th className="py-3 px-2">Email</th>
                      <th className="py-3 px-2">Телефон</th>
                      <th className="py-3 px-2">Город</th>
                      <th className="py-3 px-2">Адрес</th>
                      <th className="py-3 px-2">Дата</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u.id} className="border-b border-ink/10 align-top">
                        <td className="py-3 px-2 font-mono text-[11px] text-accent break-all">{u.id}</td>
                        <td className="py-3 px-2 font-medium">{u.name || "—"}</td>
                        <td className="py-3 px-2 text-ash break-all">{u.email || "—"}</td>
                        <td className="py-3 px-2 text-ash">{u.phone || "—"}</td>
                        <td className="py-3 px-2 text-ash">{u.city || "—"}</td>
                        <td className="py-3 px-2 text-ash max-w-[240px]">{u.address || "—"}</td>
                        <td className="py-3 px-2 text-ash whitespace-nowrap">{new Date(u.createdAt).toLocaleString("ru")}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {users.length === 0 && <p className="text-ash text-center py-12">Пользователей нет.</p>}
              </div>
            )}
            {tab === "reviews" && <div className="space-y-4">{reviews.length === 0 && <p className="text-ash text-center py-12">Отзывов нет.</p>}{reviews.slice().reverse().map(r => <div key={r.id} className="bg-cream border border-ink/10 p-4 rounded-lg"><div className="flex gap-1 text-accent-2 mb-1">{Array.from({ length: r.rating }).map((_,i) => <Icon key={i} name="star" size={14}/>)}</div><p className="text-sm mb-1">{r.text}</p><div className="text-xs text-ash">{r.userName} · {r.productName} · {new Date(r.createdAt).toLocaleDateString("ru")}</div></div>)}</div>}
            {tab === "forms" && <div className="space-y-3 max-h-[70vh] overflow-auto">{forms.length === 0 && <p className="text-ash text-center py-12">Заявок нет.</p>}{forms.slice().reverse().map(f => <div key={f.id} className="bg-cream border border-ink/10 p-4 rounded-lg"><div className="flex justify-between items-center mb-2"><span className="text-xs bg-paper px-2 py-1 rounded-full">{formLabels[f.type] || f.type}</span><span className="text-xs text-ash">{new Date(f.createdAt).toLocaleString("ru")}</span></div><div className="grid grid-cols-2 gap-1 text-xs">{Object.entries(f.data).map(([k, v]) => <div key={k}><span className="text-ash">{k}:</span> <span className="font-medium">{v}</span></div>)}</div></div>)}</div>}
          </>
        )}
      </div>
    </Section>
  );
}
