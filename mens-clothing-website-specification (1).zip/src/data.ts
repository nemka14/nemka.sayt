export type Product = {
  id: string;
  name: string;
  brand: string;
  brandTier: string;
  category: string;
  price: number;
  oldPrice?: number;
  colors: { hex: string; name: string }[];
  sizes: string[];
  material: string;
  materialTag: string;
  season: string;
  fit: string;
  style: string;
  description: string;
  care: string[];
  images: string[];
  badge?: "NEW" | "HIT" | "SALE";
  inStock: boolean;
  pairsWith: string[];
};

export const CATEGORIES = [
  { slug: "all", title: "Все" },
  { slug: "shoes", title: "Лоферы и Обувь" },
  { slug: "watches", title: "Часы" },
  { slug: "denim", title: "Брюки и Джинсы" },
  { slug: "outerwear", title: "Куртки и Верхняя одежда" },
  { slug: "shirts", title: "Рубашки и Поло" },
  { slug: "tshirts", title: "Футболки и Трикотаж" },
];

export const MATERIALS = ["Кожа", "Замша", "Сталь", "Шёлк", "Хлопок", "Шерсть", "Деним", "Фланель", "Кашемир", "Габардин"];
export const FITS = ["Прямой", "Slim-fit", "Regular", "Свободный", "Приталенный"];
export const STYLES = ["Классический", "Деловой", "Смарт-кэжуал", "Повседневный", "Элегантный", "Уличный стиль", "Аутдор"];
export const SEASONS = ["Все сезоны", "Весна / Осень", "Осень / Зима", "Лето"];

export const MESSENGERS = {
  telegram: { name: "Telegram", url: "https://t.me/nemka_mahmudov", icon: "tg" },
  vk: { name: "VK", url: "https://vk.me/nemka_store", icon: "vk" },
  max: { name: "MAX", url: "https://max.ru/nemka_store", icon: "max" },
  phone: { name: "+7 495 123-45-67", url: "tel:+74951234567", icon: "phone" },
  email: { name: "mahmudovv.14.00@gmail.com", url: "mailto:mahmudovv.14.00@gmail.com", icon: "email" },
};

const ALL_COLORS = [
  { hex: "#0a0a0a", name: "Чёрный агат" },
  { hex: "#1c1c1c", name: "Графитовый" },
  { hex: "#3a3d40", name: "Антрацит" },
  { hex: "#ffffff", name: "Ослепительно белый" },
  { hex: "#dcd1c4", name: "Песочно-бежевый" },
  { hex: "#5d634f", name: "Хаки" },
  { hex: "#1b2a4a", name: "Глубокий синий" },
  { hex: "#4a2810", name: "Горький шоколад" },
  { hex: "#5c1d24", name: "Бургунди" },
  { hex: "#b89753", name: "Матовое золото" },
];

const BRAND_TIERS = {
  shoes: [
    { tier: "Иконы стиля", brands: ["Gucci", "Tod’s", "Loro Piana"] },
    { tier: "Английская классика", brands: ["John Lobb", "Crockett & Jones", "Church’s", "Edward Green"] },
    { tier: "Премиум-комфорт", brands: ["Santoni", "Bally", "Salvatore Ferragamo"] },
    { tier: "Доступная база", brands: ["Massimo Dutti", "Meermin", "Ecco"] }
  ],
  watches: [
    { tier: "«Святая троица»", brands: ["Patek Philippe", "Audemars Piguet", "Vacheron Constantin"] },
    { tier: "Самые узнаваемые", brands: ["Rolex", "Cartier", "Omega"] },
    { tier: "Премиум и спорт", brands: ["TAG Heuer", "Breitling", "IWC", "Hublot", "Panerai"] },
    { tier: "Доступный люкс", brands: ["Tissot", "Longines", "Seiko", "Hamilton"] },
    { tier: "Практичные", brands: ["Casio G-Shock", "Citizen", "Orient", "Swatch"] }
  ],
  denim: [
    { tier: "Джинсовые легенды", brands: ["Levi's", "Wrangler", "Lee", "Diesel"] },
    { tier: "Классические брюки", brands: ["Incotex", "PT Torino", "Hugo Boss", "Brooks Brothers"] },
    { tier: "Технологичные", brands: ["Stone Island", "C.P. Company", "Carhartt WIP"] }
  ],
  outerwear: [
    { tier: "Пуховики", brands: ["Moncler", "Canada Goose", "Moose Knuckles"] },
    { tier: "Плащи и тренчи", brands: ["Burberry", "Aquascutum"] },
    { tier: "Аутдор", brands: ["The North Face", "Arc'teryx", "Patagonia", "Stone Island"] },
    { tier: "Кожаные куртки", brands: ["Schott NYC", "Saint Laurent", "Belstaff"] },
    { tier: "Бомберы", brands: ["Alpha Industries", "Baracuta"] }
  ],
  clothing: [
    { tier: "Люкс", brands: ["Gucci", "Balenciaga", "Burberry", "Givenchy"] },
    { tier: "Тихая роскошь", brands: ["Loro Piana", "Brunello Cucinelli", "Tom Ford"] },
    { tier: "Премиум-кэжуал", brands: ["Lacoste", "Ralph Lauren", "Tommy Hilfiger", "Calvin Klein"] },
    { tier: "Спорт", brands: ["Nike", "Adidas", "Under Armour", "Reebok"] },
    { tier: "База", brands: ["Uniqlo", "Zara", "H&M", "Levi's"] },
    { tier: "Streetwear", brands: ["Supreme", "Stone Island", "Off-White"] }
  ]
};

const ITEMS_POOL = {
  shoes: ["Лоферы с пряжкой", "Оксфорды ручной работы", "Мокасины мягкие", "Дерби премиум", "Монки двойные", "Броги классические", "Летние туфли"],
  watches: ["Хронограф", "Турбийон коллекционный", "Дайверские часы 300м", "Костюмные часы", "Спортивные часы", "Кварцевые часы"],
  denim: ["Джинсы Straight", "Чиносы зауженные", "Брюки фактурные", "Брюки карго", "Джинсы стрейч", "Шерстяные брюки"],
  outerwear: ["Пуховик зимний", "Тренч классический", "Куртка мембранная", "Косуха кожаная", "Бомбер MA-1", "Ветровка"],
  shirts: ["Рубашка Оксфорд", "Поло классическое", "Рубашка приталенная", "Рубашка льняная"],
  tshirts: ["Футболка Essential", "Трикотаж оверсайз", "Футболка плотная"]
};

// ═══════════════════════════════════════════════════════════
//  ТОЛЬКО ПРОВЕРЕННЫЕ ФОТО МУЖСКОЙ ОДЕЖДЫ!
//  Pexels API подтвердил — это фото обуви, часов, джинсов
//  + сгенерированные AI фото для каждой категории
// ═══════════════════════════════════════════════════════════

const LOCAL = (name: string) => `/images/${name}`;

// Фото обуви — Pexels PROVEN fashion product photos
const SHOES_POOL = [
  "https://images.pexels.com/photos/25381178/pexels-photo-25381178.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // коричневые лоферы
  "https://images.pexels.com/photos/7413278/pexels-photo-7413278.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // белые лоферы
  "https://images.pexels.com/photos/34871894/pexels-photo-34871894.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // черные лоферы
  "https://images.pexels.com/photos/34621983/pexels-photo-34621983.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // туфли на полке
  "https://images.pexels.com/photos/8394709/pexels-photo-8394709.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // лоферы + часы
  "https://images.pexels.com/photos/19165536/pexels-photo-19165536.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // ч/б туфли
  "https://images.pexels.com/photos/35538579/pexels-photo-35538579.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // лоферы на диване
  "https://images.pexels.com/photos/35564329/pexels-photo-35564329.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // черные лоферы + парфюм
  "https://images.pexels.com/photos/9965910/pexels-photo-9965910.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // коричневые туфли
  "https://images.pexels.com/photos/15557047/pexels-photo-15557047.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // черные формальные туфли
  LOCAL("shoe1.jpg"),
  LOCAL("shoe2.jpg"),
  "https://images.pexels.com/photos/30229961/pexels-photo-30229961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/35654972/pexels-photo-35654972.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/35654977/pexels-photo-35654977.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/35654924/pexels-photo-35654924.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/30272905/pexels-photo-30272905.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/35654956/pexels-photo-35654956.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/35654947/pexels-photo-35654947.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/30229956/pexels-photo-30229956.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/35654950/pexels-photo-35654950.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/35654967/pexels-photo-35654967.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
];

// Фото часов — Pexels PROVEN
const WATCHES_POOL = [
  "https://images.pexels.com/photos/14778525/pexels-photo-14778525.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // Rolex
  "https://images.pexels.com/photos/16739804/pexels-photo-16739804.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // Черные часы
  "https://images.pexels.com/photos/5168137/pexels-photo-5168137.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",   // Casio синий
  "https://images.pexels.com/photos/11607481/pexels-photo-11607481.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // Классические черные
  "https://images.pexels.com/photos/31049999/pexels-photo-31049999.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // На белых камнях
  "https://images.pexels.com/photos/16587541/pexels-photo-16587541.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // Rolex в витрине
  "https://images.pexels.com/photos/9423289/pexels-photo-9423289.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",   // Fossil
  "https://images.pexels.com/photos/2783873/pexels-photo-2783873.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",   // Michael Kors
  "https://images.pexels.com/photos/20989398/pexels-photo-20989398.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // Casio стальной
  "https://images.pexels.com/photos/34341284/pexels-photo-34341284.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // Зеленый циферблат
  LOCAL("watch1.jpg"), // сгенерированные синие часы
  LOCAL("watch2.jpg"), // сгенерированные золотые часы
];

// Фото джинсов/брюк — Pexels PROVEN
const DENIM_POOL = [
  "https://images.pexels.com/photos/23947014/pexels-photo-23947014.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // парень в дениме
  "https://images.pexels.com/photos/13921670/pexels-photo-13921670.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // парень на стуле
  "https://images.pexels.com/photos/1808181/pexels-photo-1808181.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",   // рубашка + джинсы
  "https://images.pexels.com/photos/28938765/pexels-photo-28938765.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // парень в дениме студия
  "https://images.pexels.com/photos/30710244/pexels-photo-30710244.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // джинсы + кроссовки
  "https://images.pexels.com/photos/9775494/pexels-photo-9775494.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // джинсы + кеды
  "https://images.pexels.com/photos/17265364/pexels-photo-17265364.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // стопка джинс
  "https://images.pexels.com/photos/3200073/pexels-photo-3200073.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",   // футболка + джинсы
  "https://images.pexels.com/photos/30133696/pexels-photo-30133696.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // портрет в дениме
  "https://images.pexels.com/photos/32879870/pexels-photo-32879870.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // текстура денима
];

// Фото курток — Pexels проверенные
const OUTERWEAR_POOL = [
  "https://images.pexels.com/photos/6838919/pexels-photo-6838919.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",   // кожаная куртка
  "https://images.pexels.com/photos/7414213/pexels-photo-7414213.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // кожаная куртка 2
  "https://images.pexels.com/photos/5691147/pexels-photo-5691147.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // косуха сзади
  "https://images.pexels.com/photos/6626418/pexels-photo-6626418.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // мужчина в куртке
  "https://images.pexels.com/photos/30532108/pexels-photo-30532108.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // в черном пальто
  "https://images.pexels.com/photos/5807453/pexels-photo-5807453.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // пальто
  "https://images.pexels.com/photos/4651500/pexels-photo-4651500.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",  // костюмы
  "https://images.pexels.com/photos/12056637/pexels-photo-12056637.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // в бежевом
  "https://images.pexels.com/photos/16410118/pexels-photo-16410118.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // белая рубашка зимой
  "https://images.pexels.com/photos/33561659/pexels-photo-33561659.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700", // в белом на улице
  LOCAL("jacket1.jpg"),
  LOCAL("jacket2.jpg"),
  LOCAL("outerwear1.jpg"),
];

// Фото одежды — Pexels проверенные
const CLOTHING_POOL = [
  "https://images.pexels.com/photos/6626418/pexels-photo-6626418.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/6478261/pexels-photo-6478261.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/20369255/pexels-photo-20369255.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/12056637/pexels-photo-12056637.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/30532108/pexels-photo-30532108.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/16410118/pexels-photo-16410118.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/33561659/pexels-photo-33561659.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/37070272/pexels-photo-37070272.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/8770930/pexels-photo-8770930.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/9775684/pexels-photo-9775684.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/5807453/pexels-photo-5807453.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  "https://images.pexels.com/photos/4651500/pexels-photo-4651500.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
  LOCAL("shirt1.jpg"),
  LOCAL("shirt2.jpg"),
  LOCAL("tshirt1.jpg"),
];

function pick(arr: string[], seed: number): string {
  return arr[Math.abs(seed) % arr.length];
}

function generateCatalog(): Product[] {
  const products: Product[] = [];
  let idCounter = 1;

  const targetCategories = [
    { slug: "shoes", count: 300, pool: SHOES_POOL },
    { slug: "watches", count: 250, pool: WATCHES_POOL },
    { slug: "denim", count: 200, pool: DENIM_POOL },
    { slug: "outerwear", count: 150, pool: OUTERWEAR_POOL },
    { slug: "shirts", count: 100, pool: CLOTHING_POOL },
    { slug: "tshirts", count: 85, pool: CLOTHING_POOL },
  ];

  const sizesMap: Record<string, string[]> = {
    shoes: ["40", "41", "42", "43", "44", "45", "46"],
    watches: ["38mm", "40mm", "42mm", "44mm"],
    denim: ["30", "31", "32", "33", "34", "36", "38"],
    outerwear: ["S", "M", "L", "XL", "XXL"],
    shirts: ["S", "M", "L", "XL", "XXL"],
    tshirts: ["XS", "S", "M", "L", "XL", "XXL"]
  };

  let gSeed = 1;

  for (const cat of targetCategories) {
    const tiers = BRAND_TIERS[cat.slug as keyof typeof BRAND_TIERS] || BRAND_TIERS.clothing;
    const namesList = ITEMS_POOL[cat.slug as keyof typeof ITEMS_POOL] || ITEMS_POOL.tshirts;

    for (let i = 1; i <= cat.count; i++) {
      const seed = gSeed;
      gSeed++;

      const tierObj = tiers[seed % tiers.length];
      const brand = tierObj.brands[(seed * 7 + i) % tierObj.brands.length];
      const itemName = namesList[(seed + i * 3) % namesList.length];
      const fullName = `${brand} — ${itemName} №${200 + i}`;

      // Цены от 1500₽ до 7000₽
      const price = 1500 + ((seed * 17) % 5500);

      const c1 = ALL_COLORS[seed % ALL_COLORS.length];
      const c2 = ALL_COLORS[(seed + 3) % ALL_COLORS.length];
      const c3 = ALL_COLORS[(seed + 6) % ALL_COLORS.length];
      const uniqueColors = [c1, c2, c3].filter((v, idx, self) => self.findIndex(t => t.hex === v.hex) === idx);

      const pool = cat.pool;
      const img1 = pick(pool, seed);
      const img2 = pick(pool, seed + 10);
      const img3 = pick(pool, seed + 20);

      let badge: Product["badge"] = undefined;
      if (seed % 6 === 0) badge = "NEW";
      else if (seed % 8 === 0) badge = "HIT";
      else if (seed % 10 === 0) badge = "SALE";

      products.push({
        id: `p${idCounter}`,
        name: fullName,
        brand,
        brandTier: tierObj.tier,
        category: cat.slug,
        price,
        oldPrice: badge === "SALE" ? Math.round((price * 1.3) / 100) * 100 : undefined,
        colors: uniqueColors,
        sizes: sizesMap[cat.slug] || ["M", "L"],
        material: i % 2 === 0 ? "Натуральные люксовые волокна" : "Премиальная селективная выделка",
        materialTag: i % 2 === 0 ? "Кашемир" : "Кожа",
        season: SEASONS[seed % SEASONS.length],
        fit: FITS[seed % FITS.length],
        style: STYLES[seed % STYLES.length],
        description: `Оригинальное изделие от легендарного бренда ${brand}. Безупречная посадка, благородные материалы и долговечность.`,
        care: ["Рекомендован профессиональный уход", "Хранить в вентилируемом кофре"],
        images: [img1, img2, img3],
        badge,
        inStock: seed % 14 !== 0,
        pairsWith: [`p${((idCounter + 8) % 600) + 1}`, `p${((idCounter + 24) % 600) + 1}`],
      });
      idCounter++;
    }
  }
  return products;
}

export const PRODUCTS: Product[] = generateCatalog();

export const REVIEWS = [
  { name: "Артём К.", city: "Москва", text: "Лоферы Gucci и часы Rolex просто шикарны. Качество оригинальное.", rating: 5, product: "Лоферы Gucci", photo: "https://images.pexels.com/photos/15557047/pexels-photo-15557047.jpeg?auto=compress&fit=crop&h=400&w=400" },
  { name: "Дмитрий В.", city: "Санкт-Петербург", text: "Заказал тренч Burberry. Доставили моментально, сел идеально.", rating: 5, product: "Тренч Burberry", photo: "https://images.pexels.com/photos/6838919/pexels-photo-6838919.jpeg?auto=compress&fit=crop&h=400&w=400" },
  { name: "Илья М.", city: "Казань", text: "Свитер Loro Piana невероятно мягкий. Стоит каждого рубля.", rating: 5, product: "Кашемир Loro Piana", photo: "https://images.pexels.com/photos/28938765/pexels-photo-28938765.jpeg?auto=compress&fit=crop&h=400&w=400" },
  { name: "Сергей П.", city: "Екатеринбург", text: "Джинсы Levi's 501 — вечная классика. Ткань плотная, швы ровные.", rating: 5, product: "Levi's 501", photo: "https://images.pexels.com/photos/17265364/pexels-photo-17265364.jpeg?auto=compress&fit=crop&h=400&w=400" },
];

export const BENEFITS = [
  { title: "Оригинальные бренды", text: "Прямые поставки от официальных домов моды Европы и США." },
  { title: "Тихая роскошь", text: "Премиальное качество материалов без кричащих логотипов." },
  { title: "Примерка перед оплатой", text: "Доставка курьером с возможностью оценить посадку." },
  { title: "100% Гарантия", text: "Полный возврат или замена в течение 14 дней." },
];

export const FAQ = [
  { q: "Как подобрать размер?", a: "На каждой карточке есть таблица размеров. Или напишите — поможем за 15 мин." },
  { q: "Условия доставки?", a: "Курьером по Москве/СПб — 1 день. По РФ — 2-4 дня. Бесплатно от 10 000 ₽." },
  { q: "Как связаться?", a: "Telegram, VK, MAX — отвечаем за 15 минут." },
];

export const OUTFITS = [
  { name: "Деловой эталон", desc: "Тренч Burberry, лоферы Gucci, часы Patek Philippe.", items: ["p551", "p1", "p321"], img: "https://images.pexels.com/photos/4651500/pexels-photo-4651500.jpeg?auto=compress&fit=crop&h=800&w=650" },
  { name: "Кэжуал", desc: "Кашемир Loro Piana, чиносы Incotex, кроссовки.", items: ["p701", "p581", "p101"], img: "https://images.pexels.com/photos/28938765/pexels-photo-28938765.jpeg?auto=compress&fit=crop&h=800&w=650" },
];

export const TOP_CATEGORIES_WEEK = [
  { slug: "shoes", title: "Лоферы и Обувь", subtitle: "300 моделей", img: "https://images.pexels.com/photos/25381178/pexels-photo-25381178.jpeg?auto=compress&fit=crop&h=800&w=650" },
  { slug: "watches", title: "Часы", subtitle: "250 моделей", img: "https://images.pexels.com/photos/14778525/pexels-photo-14778525.jpeg?auto=compress&fit=crop&h=800&w=650" },
  { slug: "denim", title: "Джинсы", subtitle: "200 моделей", img: "https://images.pexels.com/photos/23947014/pexels-photo-23947014.jpeg?auto=compress&fit=crop&h=800&w=650" },
];

export const HERO_IMAGES = {
  coats: "https://images.pexels.com/photos/30532108/pexels-photo-30532108.jpeg?auto=compress&fit=crop&h=800&w=650",
  whiteShirt: "https://images.pexels.com/photos/6626418/pexels-photo-6626418.jpeg?auto=compress&fit=crop&h=800&w=650",
  corduroy: "https://images.pexels.com/photos/6478261/pexels-photo-6478261.jpeg?auto=compress&fit=crop&h=800&w=650",
  suits: "https://images.pexels.com/photos/4651500/pexels-photo-4651500.jpeg?auto=compress&fit=crop&h=800&w=650",
  beige: "https://images.pexels.com/photos/12056637/pexels-photo-12056637.jpeg?auto=compress&fit=crop&h=800&w=650",
  pinkShirt: "https://images.pexels.com/photos/37070272/pexels-photo-37070272.jpeg?auto=compress&fit=crop&h=800&w=650",
  blackOutfit: "https://images.pexels.com/photos/30532108/pexels-photo-30532108.jpeg?auto=compress&fit=crop&h=800&w=650",
  whiteJacket: "https://images.pexels.com/photos/16410118/pexels-photo-16410118.jpeg?auto=compress&fit=crop&h=800&w=650",
  kurta: "https://images.pexels.com/photos/8770930/pexels-photo-8770930.jpeg?auto=compress&fit=crop&h=800&w=650",
  profile: "https://images.pexels.com/photos/9775684/pexels-photo-9775684.jpeg?auto=compress&fit=crop&h=800&w=650",
  whiteOutdoor: "https://images.pexels.com/photos/33561659/pexels-photo-33561659.jpeg?auto=compress&fit=crop&h=800&w=650",
};
