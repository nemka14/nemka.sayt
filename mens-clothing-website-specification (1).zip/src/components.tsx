import { useState } from "react";
import type { Product } from "./data";
import { MESSENGERS } from "./data";
import * as Repo from "./repository";

export type Page =
  | { name: "home" }
  | { name: "catalog"; category?: string }
  | { name: "product"; id: string }
  | { name: "cart" }
  | { name: "favorites" }
  | { name: "about" }
  | { name: "delivery" }
  | { name: "contacts" }
  | { name: "lookbook" }
  | { name: "faq" }
  | { name: "checkout" }
  | { name: "size-guide" }
  | { name: "account" }
  | { name: "login" }
  | { name: "admin" };

type NavProps = {
  navigate: (p: Page) => void;
  cartCount: number;
  favCount: number;
  page: Page;
};

/* ===================== HEADER ===================== */
export function Header({ navigate, cartCount, favCount, page }: NavProps) {
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  void page;

  const links: { label: string; page: Page }[] = [
    { label: "Каталог", page: { name: "catalog" } },
    { label: "Новинки", page: { name: "catalog", category: "all" } },
    { label: "Lookbook", page: { name: "lookbook" } },
    { label: "Бренд", page: { name: "about" } },
    { label: "Доставка", page: { name: "delivery" } },
    { label: "Контакты", page: { name: "contacts" } },
  ];

  return (
    <>
      {/* Top marquee */}
      <div className="bg-gradient-to-r from-stone via-paper to-stone text-ink text-[11px] tracking-brand uppercase py-3 overflow-hidden bg-animated">
        <div className="flex whitespace-nowrap animate-marquee">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="flex shrink-0">
              {[
                "✨ Бесплатная доставка от 10 000 ₽",
                "🔄 Возврат 14 дней",
                "🔥 Новая коллекция AW26",
                "💬 Поддержка 24/7",
              ].map((t, j) => (
                <span key={j} className="px-8 neon-text">
                  · {t}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      <header className="sticky top-0 z-40 backdrop-blur bg-paper/95 border-b border-ink/20 shadow-lg shadow-accent/10">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Burger mobile */}
            <button
              onClick={() => setOpen(true)}
              aria-label="Меню"
              className="lg:hidden p-2 -ml-2"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" strokeWidth="1.5" />
              </svg>
            </button>

            {/* Desktop nav left */}
            <nav className="hidden lg:flex items-center gap-7 text-[12.5px] uppercase tracking-[0.18em]">
              {links.slice(0, 3).map((l) => (
                <button
                  key={l.label}
                  onClick={() => navigate(l.page)}
                  className="hover:text-accent transition-colors"
                >
                  {l.label}
                </button>
              ))}
            </nav>

            {/* Logo */}
            <button
              onClick={() => navigate({ name: "home" })}
              className="flex items-center gap-2 group"
              aria-label="NEMKA"
            >
              <img
                src="/images/logo.svg"
                alt="NEMKA"
                className="h-10 lg:h-12 w-auto logo-animate transition-transform group-hover:scale-105"
              />
              <span className="font-display text-xl lg:text-2xl tracking-[0.3em] font-bold hidden sm:block">NEMKA</span>
            </button>

            {/* Desktop nav right */}
            <nav className="hidden lg:flex items-center gap-7 text-[12.5px] uppercase tracking-[0.18em]">
              {links.slice(3).map((l) => (
                <button
                  key={l.label}
                  onClick={() => navigate(l.page)}
                  className="hover:text-accent transition-colors"
                >
                  {l.label}
                </button>
              ))}
            </nav>

            {/* Icons */}
            <div className="flex items-center gap-2 lg:gap-4">
              {/* "Написать нам" — desktop */}
              <a
                href={MESSENGERS.telegram.url}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden lg:inline-flex items-center gap-1.5 px-3.5 py-1.5 border border-ink rounded-full text-[11px] uppercase tracking-[0.18em] hover:bg-ink hover:text-paper transition"
              >
                <Icon name="chat" size={14} />
                Написать
              </a>
              <button
                onClick={() => navigate({ name: "account" })}
                aria-label="Аккаунт"
                className="p-1.5 hover:text-accent transition"
              >
                <Icon name="user" />
              </button>
              <button
                onClick={() => setSearchOpen(true)}
                aria-label="Поиск"
                className="p-1.5"
              >
                <Icon name="search" />
              </button>
              <button
                onClick={() => navigate({ name: "favorites" })}
                aria-label="Избранное"
                className="p-1.5 relative"
              >
                <Icon name="heart" />
                {favCount > 0 && <Badge n={favCount} />}
              </button>
              <button
                onClick={() => navigate({ name: "cart" })}
                aria-label="Корзина"
                className="p-1.5 relative"
              >
                <Icon name="bag" />
                {cartCount > 0 && <Badge n={cartCount} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      {open && (
        <div className="fixed inset-0 z-50 bg-ink text-paper p-6 lg:hidden flex flex-col overflow-auto">
          <div className="flex items-center justify-between mb-10">
            <img src="/images/logo.svg" alt="NEMKA" className="h-12 w-auto logo-animate" />
            <button onClick={() => setOpen(false)} aria-label="Закрыть">
              <Icon name="close" />
            </button>
          </div>
          <nav className="flex flex-col gap-5 text-2xl font-display">
            {links.map((l) => (
              <button
                key={l.label}
                onClick={() => { navigate(l.page); setOpen(false); }}
                className="text-left hover:text-accent-2"
              >
                {l.label}
              </button>
            ))}
          </nav>
          <div className="border-t border-white/15 mt-8 pt-6 flex flex-col gap-4 text-base uppercase tracking-[0.2em]">
            <button onClick={() => { navigate({ name: "favorites" }); setOpen(false); }}>Избранное</button>
            <button onClick={() => { navigate({ name: "cart" }); setOpen(false); }}>Корзина</button>
            <button onClick={() => { navigate({ name: "faq" }); setOpen(false); }}>FAQ</button>
          </div>
          {/* Messengers in mobile menu */}
          <div className="border-t border-white/15 mt-6 pt-6">
            <p className="text-xs uppercase tracking-[0.25em] text-paper/50 mb-4">Написать нам</p>
            <div className="flex gap-3">
              {Object.values(MESSENGERS).filter(m => ["tg", "vk", "max"].includes(m.icon)).map((m) => (
                <a
                  key={m.name}
                  href={m.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 py-3 border border-paper/30 text-sm hover:bg-paper hover:text-ink transition rounded"
                >
                  <MessengerIcon name={m.icon} />
                  {m.name}
                </a>
              ))}
            </div>
            <a href="tel:+74951234567" className="block text-center mt-3 text-paper/70 text-sm">
              +7 495 123-45-67
            </a>
          </div>
        </div>
      )}

      {/* Search overlay */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 bg-paper p-6 lg:p-12 overflow-auto">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <span className="text-xs uppercase tracking-[0.3em]">Поиск</span>
              <button onClick={() => setSearchOpen(false)} aria-label="Закрыть">
                <Icon name="close" />
              </button>
            </div>
            <input
              autoFocus
              placeholder="Что вы ищете?"
              className="w-full text-3xl lg:text-5xl font-display border-b border-ink/40 pb-4 bg-transparent outline-none"
            />
            <div className="mt-10 text-xs uppercase tracking-[0.25em] text-ash mb-3">
              Популярное
            </div>
            <div className="flex flex-wrap gap-2">
              {["Пальто", "Рубашки белые", "Джинсы", "Пиджак", "Футболки", "Куртки"].map((t) => (
                <button
                  key={t}
                  onClick={() => { setSearchOpen(false); navigate({ name: "catalog" }); }}
                  className="px-4 py-2 border border-ink/30 rounded-full text-sm hover:bg-ink hover:text-paper transition"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Badge({ n }: { n: number }) {
  return (
    <span className="absolute -top-1 -right-1 bg-accent text-paper text-[10px] min-w-[16px] h-4 rounded-full px-1 flex items-center justify-center">
      {n}
    </span>
  );
}

/* ===================== ICONS ===================== */
export function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const props = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.5 };
  switch (name) {
    case "search":
      return <svg {...props}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>;
    case "heart":
      return <svg {...props}><path d="M12 20s-7-4.5-9-9.5C1.5 6.5 4.5 3 8 3c2 0 3.5 1 4 2.5C12.5 4 14 3 16 3c3.5 0 6.5 3.5 5 7.5-2 5-9 9.5-9 9.5Z" /></svg>;
    case "heart-fill":
      return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M12 20s-7-4.5-9-9.5C1.5 6.5 4.5 3 8 3c2 0 3.5 1 4 2.5C12.5 4 14 3 16 3c3.5 0 6.5 3.5 5 7.5-2 5-9 9.5-9 9.5Z" /></svg>;
    case "bag":
      return <svg {...props}><path d="M5 8h14l-1 12H6L5 8Z" /><path d="M9 8V6a3 3 0 0 1 6 0v2" /></svg>;
    case "close":
      return <svg {...props}><path d="M6 6l12 12M18 6L6 18" /></svg>;
    case "arrow-right":
      return <svg {...props}><path d="M5 12h14M13 6l6 6-6 6" /></svg>;
    case "plus":
      return <svg {...props}><path d="M12 5v14M5 12h14" /></svg>;
    case "minus":
      return <svg {...props}><path d="M5 12h14" /></svg>;
    case "filter":
      return <svg {...props}><path d="M3 6h18M6 12h12M10 18h4" /></svg>;
    case "check":
      return <svg {...props}><path d="M5 12l5 5L20 7" /></svg>;
    case "chat":
      return <svg {...props}><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z" /></svg>;
    case "send":
      return <svg {...props}><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z" /></svg>;
    case "star":
      return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.27 5.82 22 7 14.14l-5-4.87 6.91-1.01z" /></svg>;
    case "user":
      return <svg {...props}><circle cx="12" cy="8" r="4" /><path d="M20 21a8 8 0 0 0-16 0" /></svg>;
    case "headset":
      return <svg {...props}><path d="M3 18v-6a9 9 0 0 1 18 0v6" /><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zm-18 0a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z" /></svg>;
    case "ruler":
      return <svg {...props}><path d="M21.73 18l-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z" /><path d="M12 9v4M12 17h.01" /></svg>;
    case "shirt":
      return <svg {...props}><path d="M20.38 3.46 16 2 12 5 8 2 3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z" /></svg>;
    case "truck":
      return <svg {...props}><path d="M10 17h4V5H2v12h3" /><circle cx="7.5" cy="17.5" r="2.5" /><path d="M14 17h1" /><circle cx="17.5" cy="17.5" r="2.5" /><path d="M14 5h4l3 5v7h-2" /></svg>;
    default:
      return null;
  }
}

export function MessengerIcon({ name, size = 16 }: { name: string; size?: number }) {
  switch (name) {
    case "tg":
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
          <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0h-.056zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
        </svg>
      );
    case "vk":
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
          <path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.408 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.864-.525-2.05-1.727-1.033-1-1.49-1.135-1.744-1.135-.356 0-.458.102-.458.593v1.575c0 .424-.135.678-1.253.678-1.846 0-3.896-1.118-5.335-3.202C4.624 10.857 4.03 8.57 4.03 8.096c0-.254.102-.49.593-.49h1.744c.44 0 .61.203.78.677.864 2.49 2.303 4.675 2.896 4.675.22 0 .322-.102.322-.66V9.721c-.068-1.186-.695-1.287-.695-1.71 0-.204.17-.407.44-.407h2.744c.373 0 .508.203.508.643v3.473c0 .372.17.508.271.508.22 0 .407-.136.813-.542 1.254-1.406 2.151-3.574 2.151-3.574.119-.254.322-.49.763-.49h1.744c.525 0 .643.27.525.643-.22 1.017-2.354 4.031-2.354 4.031-.186.305-.254.44 0 .78.186.254.796.779 1.203 1.253.745.847 1.32 1.558 1.473 2.05.17.49-.085.744-.576.744z" />
        </svg>
      );
    case "max":
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
          <rect width="24" height="24" rx="5" fill="currentColor" />
          <text x="12" y="16.5" textAnchor="middle" fill="white" fontSize="10" fontWeight="700" fontFamily="sans-serif">M</text>
        </svg>
      );
    default:
      return null;
  }
}

/* ===================== FLOATING SUPPORT WIDGET ===================== */
export function SupportWidget() {
  const [open, setOpen] = useState(false);
  const channels = [
    { ...MESSENGERS.telegram, label: "Telegram", desc: "Ответ за 5 мин" },
    { ...MESSENGERS.vk, label: "VK", desc: "Сообщения сообщества" },
    { ...MESSENGERS.max, label: "MAX", desc: "Мессенджер MAX" },
    { ...MESSENGERS.phone, label: "Позвонить", desc: "+7 495 123-45-67" },
    { ...MESSENGERS.email, label: "E-mail", desc: "mahmudovv.14.00@gmail.com" },
  ];

  return (
    <>
      {/* Expanded panel */}
      {open && (
        <div className="fixed bottom-22 right-5 z-50 w-80 bg-paper border border-ink/15 shadow-2xl rounded-lg overflow-hidden">
          <div className="bg-ink text-paper px-5 py-4">
            <p className="text-xs uppercase tracking-[0.25em] text-paper/60 mb-1">Поддержка</p>
            <p className="text-sm">Отвечаем ежедневно · 09:00–22:00</p>
            <p className="text-xs text-accent-2 mt-1">Обычно отвечаем за 15 минут</p>
          </div>
          <div className="divide-y divide-ink/10">
            {channels.map((ch) => (
              <a
                key={ch.label}
                href={ch.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 px-5 py-3.5 hover:bg-cream transition"
              >
                <span className="w-9 h-9 bg-ink text-paper rounded-full flex items-center justify-center shrink-0">
                  <MessengerIcon name={ch.icon} size={16} />
                </span>
                <div>
                  <div className="text-sm font-medium">{ch.label}</div>
                  <div className="text-xs text-ash">{ch.desc}</div>
                </div>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* FAB button */}
      <button
        onClick={() => setOpen(!open)}
        aria-label="Связаться с нами"
        className="fixed bottom-5 right-5 z-50 bg-ink text-paper w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:bg-accent transition group"
      >
        {open ? (
          <Icon name="close" size={22} />
        ) : (
          <Icon name="headset" size={22} />
        )}
      </button>
      {!open && (
        <span className="fixed bottom-5 right-20 z-50 bg-ink text-paper text-xs px-3 py-1.5 rounded-full shadow-lg pointer-events-none">
          Написать нам
        </span>
      )}
    </>
  );
}

/* ===================== FOOTER ===================== */
export function Footer({ navigate }: { navigate: (p: Page) => void }) {
  return (
    <footer className="bg-ink text-paper mt-24">
      <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-16 lg:py-20">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-8">
          <div className="lg:col-span-4">
            <img src="/images/logo.svg" alt="NEMKA" className="h-14 w-auto mb-6 logo-animate" />
            <p className="text-paper/70 max-w-sm leading-relaxed">
              Современная мужская одежда. Чистый силуэт, плотные ткани и посадка, которой можно доверять.
            </p>
            <div className="mt-8">
              <p className="text-xs uppercase tracking-[0.25em] text-paper/50 mb-3">Подпишитесь · −5% на первый заказ</p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.target as HTMLFormElement;
                  const email = (form.elements.namedItem("email") as HTMLInputElement).value;
                  if (email) {
                    void Repo.saveFormSubmission("subscribe", { email, source: "footer" });
                    alert(`Спасибо! Промокод FIRST5 отправлен на ${email}`);
                    form.reset();
                  }
                }}
                className="flex border-b border-paper/30 pb-2"
              >
                <input
                  type="email"
                  name="email"
                  required
                  placeholder="Ваш E-mail"
                  className="flex-1 bg-transparent outline-none text-paper placeholder:text-paper/40"
                />
                <button className="text-xs uppercase tracking-[0.25em] hover:text-accent-2">
                  Отправить
                </button>
              </form>
            </div>
          </div>

          <FooterCol
            title="Магазин"
            items={[
              { label: "Каталог", page: { name: "catalog" } },
              { label: "Новинки", page: { name: "catalog" } },
              { label: "Хиты", page: { name: "catalog" } },
              { label: "Распродажа", page: { name: "catalog" } },
              { label: "Lookbook", page: { name: "lookbook" } },
            ]}
            navigate={navigate}
          />

          <FooterCol
            title="Сервис"
            items={[
              { label: "Доставка и оплата", page: { name: "delivery" } },
              { label: "Размерная сетка", page: { name: "size-guide" } },
              { label: "Возврат", page: { name: "delivery" } },
              { label: "FAQ", page: { name: "faq" } },
            ]}
            navigate={navigate}
          />

          <FooterCol
            title="Бренд"
            items={[
              { label: "О бренде", page: { name: "about" } },
              { label: "Контакты", page: { name: "contacts" } },
              { label: "Шоурум", page: { name: "contacts" } },
              { label: "Журнал", page: { name: "lookbook" } },
            ]}
            navigate={navigate}
          />

          <div className="lg:col-span-2">
            <p className="text-xs uppercase tracking-[0.25em] text-paper/50 mb-4">Связь</p>
            <a href="tel:+74951234567" className="block hover:text-accent-2">+7 495 123-45-67</a>
            <a href="mailto:mahmudovv.14.00@gmail.com" className="block hover:text-accent-2 mt-1">mahmudovv.14.00@gmail.com</a>
            <p className="text-xs text-paper/40 mt-1">09:00–22:00, ежедневно</p>
            {/* Messenger links with real URLs */}
            <div className="flex gap-3 mt-5">
              {[MESSENGERS.telegram, MESSENGERS.vk, MESSENGERS.max].map((m) => (
                <a
                  key={m.name}
                  href={m.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 border border-paper/30 rounded-full flex items-center justify-center hover:bg-paper hover:text-ink transition"
                  title={m.name}
                >
                  <MessengerIcon name={m.icon} size={14} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-paper/15 mt-14 pt-6 flex flex-col md:flex-row justify-between gap-3 text-xs text-paper/50">
          <span>© 2026 NEMKA. Все права защищены.</span>
          <div className="flex gap-5">
            <a href="#" className="hover:text-paper">Политика конфиденциальности</a>
            <a href="#" className="hover:text-paper">Пользовательское соглашение</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({
  title, items, navigate,
}: {
  title: string;
  items: { label: string; page: Page }[];
  navigate: (p: Page) => void;
}) {
  return (
    <div className="lg:col-span-2">
      <p className="text-xs uppercase tracking-[0.25em] text-paper/50 mb-4">{title}</p>
      <ul className="space-y-2">
        {items.map((it) => (
          <li key={it.label}>
            <button onClick={() => navigate(it.page)} className="hover:text-accent-2 transition-colors">
              {it.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ===================== PRODUCT CARD ===================== */
export function ProductCard({
  product, onOpen, onToggleFav, isFav, onQuickOrder,
}: {
  product: Product;
  onOpen: () => void;
  onToggleFav: () => void;
  isFav: boolean;
  onQuickOrder?: () => void;
}) {
  return (
    <div className="group relative card-animate">
      <button
        onClick={onOpen}
        className="block w-full overflow-hidden bg-cream aspect-[3/4] relative btn-pulse"
      >
        <img
          src={product.images[0]}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover zoom-img"
        />
        {product.badge && (
          <span
            className={`absolute top-3 left-3 text-[10px] uppercase tracking-[0.25em] px-2.5 py-1 ${
              product.badge === "SALE"
                ? "bg-accent text-paper"
                : product.badge === "NEW"
                ? "bg-ink text-paper"
                : "bg-paper text-ink"
            }`}
          >
            {product.badge === "SALE" ? "−20%" : product.badge}
          </span>
        )}
        {!product.inStock && (
          <span className="absolute top-3 right-3 bg-paper/90 text-ink text-[10px] uppercase tracking-[0.25em] px-2.5 py-1">
            Нет в наличии
          </span>
        )}
        {/* Quick order button on hover */}
        {onQuickOrder && product.inStock && (
          <span
            onClick={(e) => { e.stopPropagation(); onQuickOrder(); }}
            className="absolute bottom-0 left-0 right-0 bg-ink text-paper text-center text-xs uppercase tracking-[0.2em] py-3 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
          >
            Быстрый заказ
          </span>
        )}
      </button>
      <button
        onClick={onToggleFav}
        aria-label="В избранное"
        className="absolute top-3 right-3 p-2 text-ink hover:text-accent transition z-10"
      >
        <Icon name={isFav ? "heart-fill" : "heart"} size={18} />
      </button>
      <div className="pt-4 flex items-start justify-between gap-4">
        <div>
          <button
            onClick={onOpen}
            className="text-[15px] font-medium leading-tight text-left block hover:underline underline-offset-4"
          >
            {product.name}
          </button>
          <div className="flex items-center gap-2 mt-1">
            {product.colors.slice(0, 4).map((c, i) => (
              <span
                key={i}
                style={{ background: c.hex }}
                className="w-3 h-3 rounded-full border border-black/15"
                title={c.name}
              />
            ))}
          </div>
        </div>
        <div className="text-right shrink-0">
          {product.oldPrice && (
            <div className="text-xs text-ash line-through">
              {product.oldPrice.toLocaleString("ru")} ₽
            </div>
          )}
          <div className="text-[15px] font-semibold">
            {product.price.toLocaleString("ru")} ₽
          </div>
        </div>
      </div>
    </div>
  );
}

/* ===================== QUICK ORDER MODAL ===================== */
export function QuickOrderModal({
  product,
  onClose,
  onSuccess,
  onSubmitData,
}: {
  product: Product;
  onClose: () => void;
  onSuccess: () => void;
  onSubmitData?: (data: Record<string, string>) => void;
}) {
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState(0);

  return (
    <div className="fixed inset-0 z-50 bg-ink/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-paper w-full max-w-lg max-h-[90vh] overflow-auto p-6 lg:p-8 relative" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4" aria-label="Закрыть">
          <Icon name="close" />
        </button>
        <p className="text-xs uppercase tracking-[0.3em] text-ash mb-4">Быстрый заказ</p>
        <div className="flex gap-4 mb-6">
          <img src={product.images[0]} className="w-20 h-28 object-cover bg-cream" alt="" />
          <div>
            <p className="font-medium">{product.name}</p>
            <p className="text-lg font-semibold mt-1">{product.price.toLocaleString("ru")} ₽</p>
          </div>
        </div>

        {/* Color */}
        <p className="text-xs uppercase tracking-[0.2em] mb-2">
          Цвет · <span className="font-medium normal-case">{product.colors[selectedColor]?.name}</span>
        </p>
        <div className="flex flex-wrap gap-2 mb-5">
          {product.colors.map((c, i) => (
            <button
              key={i}
              onClick={() => setSelectedColor(i)}
              style={{ background: c.hex }}
              className={`w-9 h-9 rounded-full border-2 transition-all ${
                selectedColor === i
                  ? "border-ink ring-2 ring-ink ring-offset-2 scale-110"
                  : "border-black/15 hover:border-black/40"
              }`}
              title={c.name}
            >
              {selectedColor === i && (
                <svg className="w-3.5 h-3.5 mx-auto" viewBox="0 0 24 24" fill="none"
                  stroke={c.hex === "#ffffff" || c.hex === "#f5f0e8" || c.hex === "#e8dcc8" ? "#0a0a0a" : "#ffffff"} strokeWidth="3">
                  <path d="M5 12l5 5L20 7" />
                </svg>
              )}
            </button>
          ))}
        </div>

        {/* Size */}
        <p className="text-xs uppercase tracking-[0.2em] mb-2">Размер</p>
        <div className="flex flex-wrap gap-2 mb-5">
          {product.sizes.map((s) => (
            <button
              key={s}
              onClick={() => setSelectedSize(s)}
              className={`px-3 py-2 border text-sm transition ${
                selectedSize === s ? "bg-ink text-paper border-ink" : "border-ink/25 hover:border-ink"
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!selectedSize) { alert("Выберите размер"); return; }
            const data = Object.fromEntries(new FormData(e.target as HTMLFormElement).entries()) as Record<string, string>;
            onSubmitData?.({ ...data, size: selectedSize, color: product.colors[selectedColor]?.name || "", product: product.name });
            onSuccess();
          }}
          className="space-y-3"
        >
          <input
            name="name"
            required
            placeholder="Ваше имя"
            className="w-full border border-ink/20 px-4 py-3 outline-none focus:border-ink bg-transparent"
          />
          <input
            name="phone"
            required
            type="tel"
            placeholder="Телефон"
            className="w-full border border-ink/20 px-4 py-3 outline-none focus:border-ink bg-transparent"
          />
          <p className="text-xs text-ash">Перезвоним в течение 15 минут, уточним адрес и доставим.</p>
          <Btn full type="submit">Заказать</Btn>
        </form>
      </div>
    </div>
  );
}

/* ===================== FORM MODALS ===================== */
export function FormModal({
  title, subtitle, fields, onClose, onSuccess, submitLabel, onSubmitData,
}: {
  title: string;
  subtitle: string;
  fields: { name: string; label: string; type?: string; required?: boolean; textarea?: boolean; options?: string[] }[];
  onClose: () => void;
  onSuccess: () => void;
  submitLabel?: string;
  onSubmitData?: (data: Record<string, string>) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-ink/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-paper w-full max-w-lg max-h-[90vh] overflow-auto p-6 lg:p-8 relative" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4" aria-label="Закрыть">
          <Icon name="close" />
        </button>
        <p className="text-xs uppercase tracking-[0.3em] text-ash mb-2">{title}</p>
        <p className="text-sm text-ash mb-6">{subtitle}</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const data = Object.fromEntries(new FormData(e.target as HTMLFormElement).entries()) as Record<string, string>;
            onSubmitData?.(data);
            onSuccess();
          }}
          className="space-y-4"
        >
          {fields.map((f) => (
            <label key={f.name} className="block">
              <span className="text-xs uppercase tracking-[0.2em] text-ash block mb-1.5">{f.label}</span>
              {f.textarea ? (
                <textarea
                  name={f.name}
                  rows={3}
                  required={f.required}
                  className="w-full border border-ink/20 px-4 py-3 outline-none focus:border-ink bg-transparent"
                />
              ) : f.options ? (
                <select
                  name={f.name}
                  required={f.required}
                  className="w-full border border-ink/20 px-4 py-3 outline-none focus:border-ink bg-transparent"
                >
                  <option value="">Выберите</option>
                  {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : (
                <input
                  type={f.type ?? "text"}
                  name={f.name}
                  required={f.required}
                  className="w-full border border-ink/20 px-4 py-3 outline-none focus:border-ink bg-transparent"
                />
              )}
            </label>
          ))}
          <Btn full type="submit">{submitLabel ?? "Отправить"}</Btn>
        </form>
      </div>
    </div>
  );
}

/* ===================== UTILS ===================== */
export function Section({
  eyebrow, title, children, className = "",
}: {
  eyebrow?: string;
  title?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`max-w-[1400px] mx-auto px-5 lg:px-10 py-16 lg:py-24 ${className}`}>
      {(eyebrow || title) && (
        <div className="flex items-end justify-between mb-10 lg:mb-14 gap-6">
          <div>
            {eyebrow && (
              <p className="text-xs uppercase tracking-[0.3em] text-ash mb-3">{eyebrow}</p>
            )}
            {title && (
              <h2 className="font-display text-3xl md:text-5xl lg:text-6xl leading-[0.95]">
                {title}
              </h2>
            )}
          </div>
        </div>
      )}
      {children}
    </section>
  );
}

export function Btn({
  children, onClick, variant = "primary", full = false, type,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "outline";
  full?: boolean;
  type?: "button" | "submit";
}) {
  const base = "inline-flex items-center justify-center gap-2 px-7 py-4 text-xs uppercase tracking-[0.25em] transition cursor-pointer";
  const styles = {
    primary: "bg-ink text-paper hover:bg-accent",
    ghost: "bg-paper text-ink hover:bg-ink hover:text-paper border border-ink",
    outline: "bg-transparent text-paper border border-paper/60 hover:bg-paper hover:text-ink",
  };
  return (
    <button
      type={type ?? "button"}
      onClick={onClick}
      className={`${base} ${styles[variant]} ${full ? "w-full" : ""}`}
    >
      {children}
    </button>
  );
}
