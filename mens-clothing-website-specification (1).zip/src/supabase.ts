import { createClient } from "@supabase/supabase-js";

// ═══════════════════════════════════════════════
//  SUPABASE — Подключение к облачной базе данных
// ═══════════════════════════════════════════════
//
//  КАК НАСТРОИТЬ:
//  1. Зайди на https://supabase.com → Create Project
//  2. Скопируй URL и anon key из Settings → API
//  3. Вставь сюда ↓↓↓
//
// ═══════════════════════════════════════════════

const SUPABASE_URL = "https://wevismknzajfpjrkwkxm.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndldmlzbWtuemFqZnBqcmt3a3htIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk0NDgwNTMsImV4cCI6MjA5NTAyNDA1M30.m-7K--89v3hkZRDdejAMavjNUwFG6GQRRK89Ot6ZnyE";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ═══════════════════════════════════════════════
//  SQL для создания таблиц в Supabase:
//  Вставь в SQL Editor → Run
// ═══════════════════════════════════════════════
//
//  -- Пользователи
//  CREATE TABLE users (
//    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
//    name TEXT NOT NULL,
//    email TEXT UNIQUE NOT NULL,
//    phone TEXT,
//    password TEXT,
//    city TEXT,
//    address TEXT,
//    created_at TIMESTAMPTZ DEFAULT NOW()
//  );
//
//  -- Заказы
//  CREATE TABLE orders (
//    id TEXT PRIMARY KEY,
//    user_id TEXT,
//    items JSONB NOT NULL,
//    total INTEGER NOT NULL,
//    shipping INTEGER DEFAULT 0,
//    status TEXT DEFAULT 'new',
//    delivery TEXT,
//    payment TEXT,
//    comment TEXT,
//    name TEXT,
//    phone TEXT,
//    email TEXT,
//    city TEXT,
//    address TEXT,
//    created_at TIMESTAMPTZ DEFAULT NOW()
//  );
//
//  -- Отзывы
//  CREATE TABLE reviews (
//    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
//    user_id TEXT,
//    user_name TEXT,
//    product_id TEXT,
//    product_name TEXT,
//    rating INTEGER,
//    text TEXT,
//    created_at TIMESTAMPTZ DEFAULT NOW()
//  );
//
//  -- Заявки с форм
//  CREATE TABLE form_submissions (
//    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
//    type TEXT NOT NULL,
//    data JSONB NOT NULL,
//    created_at TIMESTAMPTZ DEFAULT NOW()
//  );
//
//  -- Подписки
//  CREATE TABLE subscribers (
//    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
//    email TEXT UNIQUE NOT NULL,
//    created_at TIMESTAMPTZ DEFAULT NOW()
//  );
//
//  -- RLS (Row Level Security) — разрешаем всё для anon
//  ALTER TABLE users ENABLE ROW LEVEL SECURITY;
//  ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
//  ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
//  ALTER TABLE form_submissions ENABLE ROW LEVEL SECURITY;
//  ALTER TABLE subscribers ENABLE ROW LEVEL SECURITY;
//
//  CREATE POLICY "Allow all" ON users FOR ALL USING (true);
//  CREATE POLICY "Allow all" ON orders FOR ALL USING (true);
//  CREATE POLICY "Allow all" ON reviews FOR ALL USING (true);
//  CREATE POLICY "Allow all" ON form_submissions FOR ALL USING (true);
//  CREATE POLICY "Allow all" ON subscribers FOR ALL USING (true);
//

// ═══════════════════════════════════════════════
//  API-функции для работы с Supabase
// ═══════════════════════════════════════════════

// Проверка подключения
export function isSupabaseConfigured(): boolean {
  return !SUPABASE_URL.includes("YOUR_PROJECT");
}

// ── USERS ──

export async function registerUserSupabase(name: string, email: string, phone: string) {
  const { data, error } = await supabase
    .from("users")
    .insert([{ name, email, phone }])
    .select()
    .single();
  if (error) return { error: error.message };
  return { data };
}

export async function loginUserSupabase(email: string) {
  const { data, error } = await supabase
    .from("users")
    .select("*")
    .eq("email", email)
    .single();
  if (error) return { error: "Пользователь не найден" };
  return { data };
}

export async function getAllUsersSupabase() {
  const { data } = await supabase.from("users").select("*").order("created_at", { ascending: false });
  return data || [];
}

// ── ORDERS ──

export async function createOrderSupabase(order: {
  id: string;
  user_id: string;
  items: unknown[];
  total: number;
  shipping: number;
  status: string;
  delivery: string;
  payment: string;
  comment: string;
  name: string;
  phone: string;
  email: string;
  city: string;
  address: string;
}) {
  const { data, error } = await supabase.from("orders").insert([order]).select().single();
  if (error) return { error: error.message };
  return { data };
}

export async function getOrdersByUserSupabase(userId: string) {
  const { data } = await supabase.from("orders").select("*").eq("user_id", userId).order("created_at", { ascending: false });
  return data || [];
}

export async function getAllOrdersSupabase() {
  const { data } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
  return data || [];
}

export async function updateOrderStatusSupabase(orderId: string, status: string) {
  const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);
  return !error;
}

// ── REVIEWS ──

export async function addReviewSupabase(review: {
  user_id: string;
  user_name: string;
  product_id: string;
  product_name: string;
  rating: number;
  text: string;
}) {
  const { data, error } = await supabase.from("reviews").insert([review]).select().single();
  if (error) return { error: error.message };
  return { data };
}

export async function getReviewsByProductSupabase(productId: string) {
  const { data } = await supabase.from("reviews").select("*").eq("product_id", productId).order("created_at", { ascending: false });
  return data || [];
}

export async function getAllReviewsSupabase() {
  const { data } = await supabase.from("reviews").select("*").order("created_at", { ascending: false });
  return data || [];
}

// ── FORM SUBMISSIONS ──

export async function saveFormSupabase(type: string, formData: Record<string, string>) {
  const { error } = await supabase.from("form_submissions").insert([{ type, data: formData }]);
  return !error;
}

export async function getAllFormsSupabase() {
  const { data } = await supabase.from("form_submissions").select("*").order("created_at", { ascending: false });
  return data || [];
}

// ── SUBSCRIBERS ──

export async function addSubscriberSupabase(email: string) {
  const { error } = await supabase.from("subscribers").insert([{ email }]);
  return !error;
}

export async function getAllSubscribersSupabase() {
  const { data } = await supabase.from("subscribers").select("*").order("created_at", { ascending: false });
  return data || [];
}

// ── STATS ──

export async function getDbStatsSupabase() {
  const [users, orders, reviews, forms, subs] = await Promise.all([
    supabase.from("users").select("id", { count: "exact", head: true }),
    supabase.from("orders").select("*"),
    supabase.from("reviews").select("id", { count: "exact", head: true }),
    supabase.from("form_submissions").select("id", { count: "exact", head: true }),
    supabase.from("subscribers").select("id", { count: "exact", head: true }),
  ]);

  const ordersList = orders.data || [];

  return {
    users: users.count || 0,
    orders: ordersList.length,
    reviews: reviews.count || 0,
    forms: forms.count || 0,
    subscribers: subs.count || 0,
    totalRevenue: ordersList.reduce((a: number, o: { total: number }) => a + (o.total || 0), 0),
    newOrders: ordersList.filter((o: { status: string }) => o.status === "new").length,
    processingOrders: ordersList.filter((o: { status: string }) => o.status === "processing").length,
    shippedOrders: ordersList.filter((o: { status: string }) => o.status === "shipped").length,
    deliveredOrders: ordersList.filter((o: { status: string }) => o.status === "delivered").length,
  };
}
