// ═══════════════════════════════════════════════
//  TELEGRAM NOTIFICATIONS
// ═══════════════════════════════════════════════
// Чтобы уведомления реально приходили в Telegram, заполни 2 поля:
// 1) BOT TOKEN — получи у @BotFather
// 2) CHAT ID — напиши своему боту /start, потом узнай chat_id через @userinfobot
//    или через запрос: https://api.telegram.org/bot<TOKEN>/getUpdates
//
// ВАЖНО:
// - username вроде @nemka_mahmudov недостаточно для личных сообщений
// - нужен именно CHAT ID (обычно число)
// - бот должен быть сначала запущен тобой в Telegram
//
// Для продакшена лучше вынести это на сервер / Supabase Edge Function,
// но сейчас я делаю прямо в сайте, чтобы быстро заработало.

const TELEGRAM_BOT_TOKEN = "8709461938:AAFxSDQCUtg9VsDWrvtfBX7H9IAPwmaBdIc";
const TELEGRAM_CHAT_ID = "5299268915";
const TELEGRAM_CHAT_CACHE_KEY = "nemka_telegram_chat_id";

export function isTelegramConfigured(): boolean {
  return (
    TELEGRAM_BOT_TOKEN.length > 20 &&
    !TELEGRAM_BOT_TOKEN.includes("PASTE_YOUR_BOT_TOKEN_HERE")
  );
}


export async function getTelegramStatus(): Promise<{ ok: boolean; message: string; chatId?: string | null }> {
  if (!isTelegramConfigured()) {
    return { ok: false, message: "Bot token не настроен" };
  }
  if (!TELEGRAM_CHAT_ID) {
    return {
      ok: false,
      message: "Не найден chat_id.",
      chatId: null,
    };
  }
  return { ok: true, message: "Telegram уведомления готовы к отправке.", chatId: TELEGRAM_CHAT_ID };
}

async function sendTelegramMessage(text: string): Promise<boolean> {
  if (!isTelegramConfigured()) return false;
  try {
    const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

function formatTime(date = new Date()): string {
  return date.toLocaleString("ru-RU", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export async function notifyTelegramRegistration(payload: {
  name: string;
  email: string;
  phone: string;
  source?: string;
}) {
  const text = [
    "🆕 <b>Новая регистрация на NEMKA</b>",
    "",
    `<b>Имя:</b> ${payload.name || "—"}`,
    `<b>Email:</b> ${payload.email || "—"}`,
    `<b>Телефон:</b> ${payload.phone || "—"}`,
    `<b>Источник:</b> ${payload.source || "site"}`,
    `<b>Время:</b> ${formatTime()}`,
  ].join("\n");
  return sendTelegramMessage(text);
}

export async function notifyTelegramLogin(payload: {
  name: string;
  email: string;
  phone?: string;
  source?: string;
}) {
  const text = [
    "🔐 <b>Пользователь вошёл в аккаунт</b>",
    "",
    `<b>Имя:</b> ${payload.name || "—"}`,
    `<b>Email:</b> ${payload.email || "—"}`,
    `<b>Телефон:</b> ${payload.phone || "—"}`,
    `<b>Источник:</b> ${payload.source || "site"}`,
    `<b>Время:</b> ${formatTime()}`,
  ].join("\n");
  return sendTelegramMessage(text);
}

export async function notifyTelegramOrder(payload: {
  orderId: string;
  name: string;
  phone: string;
  email: string;
  total: number;
  city: string;
  address: string;
  itemsCount: number;
}) {
  const text = [
    "📦 <b>Новый заказ на NEMKA</b>",
    "",
    `<b>Заказ:</b> ${payload.orderId}`,
    `<b>Клиент:</b> ${payload.name || "—"}`,
    `<b>Телефон:</b> ${payload.phone || "—"}`,
    `<b>Email:</b> ${payload.email || "—"}`,
    `<b>Город:</b> ${payload.city || "—"}`,
    `<b>Адрес:</b> ${payload.address || "—"}`,
    `<b>Товаров:</b> ${payload.itemsCount}`,
    `<b>Сумма:</b> ${payload.total.toLocaleString("ru-RU")} ₽`,
    `<b>Время:</b> ${formatTime()}`,
  ].join("\n");
  return sendTelegramMessage(text);
}

export async function notifyTelegramForm(payload: {
  type: string;
  name?: string;
  phone?: string;
  email?: string;
}) {
  const text = [
    "📝 <b>Новая заявка с сайта NEMKA</b>",
    "",
    `<b>Тип:</b> ${payload.type}`,
    `<b>Имя:</b> ${payload.name || "—"}`,
    `<b>Телефон:</b> ${payload.phone || "—"}`,
    `<b>Email:</b> ${payload.email || "—"}`,
    `<b>Время:</b> ${formatTime()}`,
  ].join("\n");
  return sendTelegramMessage(text);
}

export async function sendTelegramTestMessage() {
  return sendTelegramMessage(["✅ <b>Тест Telegram уведомлений NEMKA</b>", "", `<b>Время:</b> ${formatTime()}`].join("\n"));
}

export function clearTelegramChatCache() {
  localStorage.removeItem(TELEGRAM_CHAT_CACHE_KEY);
}
