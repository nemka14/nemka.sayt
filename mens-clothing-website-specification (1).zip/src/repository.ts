import * as LocalDB from "./db";
import type { User, Order, Review, FormSubmission } from "./db";
import { isSupabaseConfigured, supabase } from "./supabase";
import {
  notifyTelegramForm,
  notifyTelegramLogin,
  notifyTelegramOrder,
  notifyTelegramRegistration,
} from "./telegram";

function normalizeUser(row: any): User {
  return {
    id: row.id,
    name: row.name ?? "",
    email: row.email ?? "",
    phone: row.phone ?? "",
    password: row.password ?? "",
    city: row.city ?? "",
    address: row.address ?? "",
    createdAt: row.created_at ?? row.createdAt ?? new Date().toISOString(),
  };
}

function normalizeOrder(row: any): Order {
  return {
    id: row.id,
    userId: row.user_id ?? row.userId ?? "guest",
    items: row.items ?? [],
    total: row.total ?? 0,
    shipping: row.shipping ?? 0,
    status: row.status ?? "new",
    delivery: row.delivery ?? "",
    payment: row.payment ?? "",
    comment: row.comment ?? "",
    name: row.name ?? "",
    phone: row.phone ?? "",
    email: row.email ?? "",
    city: row.city ?? "",
    address: row.address ?? "",
    createdAt: row.created_at ?? row.createdAt ?? new Date().toISOString(),
  };
}

function normalizeReview(row: any): Review {
  return {
    id: row.id,
    userId: row.user_id ?? row.userId ?? "",
    userName: row.user_name ?? row.userName ?? "",
    productId: row.product_id ?? row.productId ?? "",
    productName: row.product_name ?? row.productName ?? "",
    rating: row.rating ?? 5,
    text: row.text ?? "",
    createdAt: row.created_at ?? row.createdAt ?? new Date().toISOString(),
  };
}

function normalizeForm(row: any): FormSubmission {
  return {
    id: row.id,
    type: row.type,
    data: row.data ?? {},
    createdAt: row.created_at ?? row.createdAt ?? new Date().toISOString(),
  };
}

export async function registerUser(name: string, email: string, phone: string, password: string): Promise<User | string> {
  if (isSupabaseConfigured()) {
    try {
      const { data: exists, error: existsError } = await supabase.from("users").select("id").eq("email", email).maybeSingle();
      if (!existsError && exists) return "Пользователь с таким email уже зарегистрирован";
      const { data, error } = await supabase
        .from("users")
        .insert([{ name, email, phone, password, city: "", address: "" }])
        .select()
        .single();
      if (!error && data) {
        void notifyTelegramRegistration({ name, email, phone, source: "supabase" });
        return normalizeUser(data);
      }
      const localUser = LocalDB.registerUser(name, email, phone, password);
      if (typeof localUser !== "string") {
        void notifyTelegramRegistration({ name, email, phone, source: "local" });
      }
      return localUser;
    } catch {
      const localUser = LocalDB.registerUser(name, email, phone, password);
      if (typeof localUser !== "string") {
        void notifyTelegramRegistration({ name, email, phone, source: "local" });
      }
      return localUser;
    }
  }
  const localUser = LocalDB.registerUser(name, email, phone, password);
  if (typeof localUser !== "string") {
    void notifyTelegramRegistration({ name, email, phone, source: "local" });
  }
  return localUser;
}

export async function loginUser(email: string, password: string): Promise<User | string> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase
        .from("users")
        .select("*")
        .eq("email", email)
        .eq("password", password)
        .maybeSingle();
      if (!error && data) {
        const user = normalizeUser(data);
        void notifyTelegramLogin({ name: user.name, email: user.email, phone: user.phone, source: "supabase" });
        return user;
      }
      const localUser = LocalDB.loginUser(email, password);
      if (typeof localUser !== "string") {
        void notifyTelegramLogin({ name: localUser.name, email: localUser.email, phone: localUser.phone, source: "local" });
      }
      return localUser;
    } catch {
      const localUser = LocalDB.loginUser(email, password);
      if (typeof localUser !== "string") {
        void notifyTelegramLogin({ name: localUser.name, email: localUser.email, phone: localUser.phone, source: "local" });
      }
      return localUser;
    }
  }
  const localUser = LocalDB.loginUser(email, password);
  if (typeof localUser !== "string") {
    void notifyTelegramLogin({ name: localUser.name, email: localUser.email, phone: localUser.phone, source: "local" });
  }
  return localUser;
}

export async function getUserById(userId: string): Promise<User | null> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.from("users").select("*").eq("id", userId).maybeSingle();
      if (!error && data) return normalizeUser(data);
      return LocalDB.getUser(userId);
    } catch {
      return LocalDB.getUser(userId);
    }
  }
  return LocalDB.getUser(userId);
}

export async function getAllUsers(): Promise<User[]> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.from("users").select("*").order("created_at", { ascending: false });
      if (!error && data) return data.map(normalizeUser);
      return LocalDB.getAllUsers();
    } catch {
      return LocalDB.getAllUsers();
    }
  }
  return LocalDB.getAllUsers();
}

export async function createOrder(order: Omit<Order, "id" | "createdAt" | "status">): Promise<Order> {
  if (isSupabaseConfigured()) {
    try {
      const id = `ORD-${Date.now().toString(36).toUpperCase()}`;
      const payload = {
        id,
        user_id: order.userId,
        items: order.items,
        total: order.total,
        shipping: order.shipping,
        status: "new",
        delivery: order.delivery,
        payment: order.payment,
        comment: order.comment,
        name: order.name,
        phone: order.phone,
        email: order.email,
        city: order.city,
        address: order.address,
      };
      const { data, error } = await supabase.from("orders").insert([payload]).select().single();
      if (!error && data) {
        void notifyTelegramOrder({ orderId: id, name: order.name, phone: order.phone, email: order.email, total: order.total, city: order.city, address: order.address, itemsCount: order.items.length });
        return normalizeOrder(data);
      }
      const localOrder = LocalDB.createOrder(order);
      void notifyTelegramOrder({ orderId: localOrder.id, name: localOrder.name, phone: localOrder.phone, email: localOrder.email, total: localOrder.total, city: localOrder.city, address: localOrder.address, itemsCount: localOrder.items.length });
      return localOrder;
    } catch {
      const localOrder = LocalDB.createOrder(order);
      void notifyTelegramOrder({ orderId: localOrder.id, name: localOrder.name, phone: localOrder.phone, email: localOrder.email, total: localOrder.total, city: localOrder.city, address: localOrder.address, itemsCount: localOrder.items.length });
      return localOrder;
    }
  }
  const localOrder = LocalDB.createOrder(order);
  void notifyTelegramOrder({ orderId: localOrder.id, name: localOrder.name, phone: localOrder.phone, email: localOrder.email, total: localOrder.total, city: localOrder.city, address: localOrder.address, itemsCount: localOrder.items.length });
  return localOrder;
}

export async function getOrdersByUser(userId: string): Promise<Order[]> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.from("orders").select("*").eq("user_id", userId).order("created_at", { ascending: false });
      if (!error && data) return data.map(normalizeOrder);
      return LocalDB.getOrdersByUser(userId);
    } catch {
      return LocalDB.getOrdersByUser(userId);
    }
  }
  return LocalDB.getOrdersByUser(userId);
}

export async function getAllOrders(): Promise<Order[]> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
      if (!error && data) return data.map(normalizeOrder);
      return LocalDB.getAllOrders();
    } catch {
      return LocalDB.getAllOrders();
    }
  }
  return LocalDB.getAllOrders();
}

export async function updateOrderStatus(orderId: string, status: Order["status"]): Promise<boolean> {
  if (isSupabaseConfigured()) {
    try {
      const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);
      if (!error) return true;
      return !!LocalDB.updateOrderStatus(orderId, status);
    } catch {
      return !!LocalDB.updateOrderStatus(orderId, status);
    }
  }
  return !!LocalDB.updateOrderStatus(orderId, status);
}

export async function addReview(review: Omit<Review, "id" | "createdAt">): Promise<Review> {
  if (isSupabaseConfigured()) {
    try {
      const payload = {
        user_id: review.userId,
        user_name: review.userName,
        product_id: review.productId,
        product_name: review.productName,
        rating: review.rating,
        text: review.text,
      };
      const { data, error } = await supabase.from("reviews").insert([payload]).select().single();
      if (!error && data) return normalizeReview(data);
      return LocalDB.addReview(review);
    } catch {
      return LocalDB.addReview(review);
    }
  }
  return LocalDB.addReview(review);
}

export async function getReviewsByProduct(productId: string): Promise<Review[]> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.from("reviews").select("*").eq("product_id", productId).order("created_at", { ascending: false });
      if (!error && data) return data.map(normalizeReview);
      return LocalDB.getReviewsByProduct(productId);
    } catch {
      return LocalDB.getReviewsByProduct(productId);
    }
  }
  return LocalDB.getReviewsByProduct(productId);
}

export async function getAllReviews(): Promise<Review[]> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.from("reviews").select("*").order("created_at", { ascending: false });
      if (!error && data) return data.map(normalizeReview);
      return LocalDB.getAllReviews();
    } catch {
      return LocalDB.getAllReviews();
    }
  }
  return LocalDB.getAllReviews();
}

export async function saveFormSubmission(type: FormSubmission["type"], data: Record<string, string>): Promise<FormSubmission> {
  if (isSupabaseConfigured()) {
    try {
      const { data: row, error } = await supabase.from("form_submissions").insert([{ type, data }]).select().single();
      if (!error && row) {
        void notifyTelegramForm({ type, name: data.name, phone: data.phone, email: data.email });
        return normalizeForm(row);
      }
      const localForm = LocalDB.saveFormSubmission(type, data);
      void notifyTelegramForm({ type, name: data.name, phone: data.phone, email: data.email });
      return localForm;
    } catch {
      const localForm = LocalDB.saveFormSubmission(type, data);
      void notifyTelegramForm({ type, name: data.name, phone: data.phone, email: data.email });
      return localForm;
    }
  }
  const localForm = LocalDB.saveFormSubmission(type, data);
  void notifyTelegramForm({ type, name: data.name, phone: data.phone, email: data.email });
  return localForm;
}

export async function getAllFormSubmissions(): Promise<FormSubmission[]> {
  if (isSupabaseConfigured()) {
    try {
      const { data, error } = await supabase.from("form_submissions").select("*").order("created_at", { ascending: false });
      if (!error && data) return data.map(normalizeForm);
      return LocalDB.getAllFormSubmissions();
    } catch {
      return LocalDB.getAllFormSubmissions();
    }
  }
  return LocalDB.getAllFormSubmissions();
}

export async function getDbStats() {
  if (isSupabaseConfigured()) {
    try {
      const [usersRes, ordersRes, reviewsRes, formsRes] = await Promise.all([
        supabase.from("users").select("id", { count: "exact", head: true }),
        supabase.from("orders").select("id,total,status"),
        supabase.from("reviews").select("id", { count: "exact", head: true }),
        supabase.from("form_submissions").select("id", { count: "exact", head: true }),
      ]);
      const orders = ordersRes.data || [];
      return {
        users: usersRes.count || 0,
        orders: orders.length,
        reviews: reviewsRes.count || 0,
        forms: formsRes.count || 0,
        totalRevenue: orders.reduce((a, o: any) => a + (o.total || 0), 0),
        newOrders: orders.filter((o: any) => o.status === "new").length,
        processingOrders: orders.filter((o: any) => o.status === "processing").length,
        shippedOrders: orders.filter((o: any) => o.status === "shipped").length,
        deliveredOrders: orders.filter((o: any) => o.status === "delivered").length,
      };
    } catch {
      return LocalDB.getDbStats();
    }
  }
  return LocalDB.getDbStats();
}

export async function getBackendStatus(): Promise<{ mode: "supabase" | "local"; ok: boolean; message: string }> {
  if (!isSupabaseConfigured()) {
    return { mode: "local", ok: false, message: "Supabase не настроен. Сейчас используется localStorage." };
  }
  try {
    const { error } = await supabase.from("users").select("id").limit(1);
    if (error) {
      return {
        mode: "local",
        ok: false,
        message: `Supabase недоступен для записи/чтения: ${error.message}`,
      };
    }
    return { mode: "supabase", ok: true, message: "Supabase подключён. Данные пишутся в облако." };
  } catch (e) {
    return {
      mode: "local",
      ok: false,
      message: `Ошибка подключения к Supabase. Используется localStorage.`,
    };
  }
}

export async function syncLocalDataToSupabase(): Promise<{ ok: boolean; message: string }> {
  if (!isSupabaseConfigured()) {
    return { ok: false, message: "Supabase не настроен." };
  }
  try {
    const users = LocalDB.getAllUsers();
    const orders = LocalDB.getAllOrders();
    const reviews = LocalDB.getAllReviews();
    const forms = LocalDB.getAllFormSubmissions();

    if (users.length) {
      await supabase.from("users").upsert(
        users.map((u) => ({
          id: u.id,
          name: u.name,
          email: u.email,
          phone: u.phone,
          password: u.password,
          city: u.city,
          address: u.address,
          created_at: u.createdAt,
        })),
        { onConflict: "id" }
      );
    }

    if (orders.length) {
      await supabase.from("orders").upsert(
        orders.map((o) => ({
          id: o.id,
          user_id: o.userId,
          items: o.items,
          total: o.total,
          shipping: o.shipping,
          status: o.status,
          delivery: o.delivery,
          payment: o.payment,
          comment: o.comment,
          name: o.name,
          phone: o.phone,
          email: o.email,
          city: o.city,
          address: o.address,
          created_at: o.createdAt,
        })),
        { onConflict: "id" }
      );
    }

    if (reviews.length) {
      await supabase.from("reviews").upsert(
        reviews.map((r) => ({
          id: r.id,
          user_id: r.userId,
          user_name: r.userName,
          product_id: r.productId,
          product_name: r.productName,
          rating: r.rating,
          text: r.text,
          created_at: r.createdAt,
        })),
        { onConflict: "id" }
      );
    }

    if (forms.length) {
      await supabase.from("form_submissions").upsert(
        forms.map((f) => ({
          id: f.id,
          type: f.type,
          data: f.data,
          created_at: f.createdAt,
        })),
        { onConflict: "id" }
      );
    }

    return {
      ok: true,
      message: `Синхронизация завершена: users ${users.length}, orders ${orders.length}, reviews ${reviews.length}, forms ${forms.length}.`,
    };
  } catch (e) {
    return { ok: false, message: "Не удалось синхронизировать localStorage с Supabase." };
  }
}

export const session = {
  save: LocalDB.saveSession,
  load: LocalDB.loadSession,
  clear: LocalDB.clearSession,
};
