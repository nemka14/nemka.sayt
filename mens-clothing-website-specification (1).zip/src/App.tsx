import { useEffect, useMemo, useState } from "react";
import { Header, Footer, SupportWidget } from "./components";
import type { Page } from "./components";
import {
  HomePage,
  CatalogPage,
  ProductPage,
  CartPage,
  FavoritesPage,
  AboutPage,
  DeliveryPage,
  ContactsPage,
  LookbookPage,
  FaqPage,
  CheckoutPage,
  SizeGuidePage,
} from "./pages";
import { AccountPage, LoginPage, AdminPage } from "./dbpages";
import type { User } from "./db";
import { getUserById, session } from "./repository";

type CartItem = { id: string; size: string; qty: number };

function pageToHash(page: Page): string {
  switch (page.name) {
    case "home":
      return "#home";
    case "catalog":
      return page.category ? `#catalog-${encodeURIComponent(page.category)}` : "#catalog";
    case "product":
      return `#product-${encodeURIComponent(page.id)}`;
    case "cart":
      return "#cart";
    case "favorites":
      return "#favorites";
    case "about":
      return "#about";
    case "delivery":
      return "#delivery";
    case "contacts":
      return "#contacts";
    case "lookbook":
      return "#lookbook";
    case "faq":
      return "#faq";
    case "checkout":
      return "#checkout";
    case "size-guide":
      return "#size-guide";
    case "account":
      return "#account";
    case "login":
      return "#login";
    case "admin":
      return "#admin";
    default:
      return "#home";
  }
}

function hashToPage(hash: string): Page {
  const clean = hash.replace(/^#/, "").trim();
  if (!clean) return { name: "home" };

  if (clean.startsWith("catalog-")) {
    return { name: "catalog", category: decodeURIComponent(clean.replace("catalog-", "")) };
  }
  if (clean.startsWith("product-")) {
    return { name: "product", id: decodeURIComponent(clean.replace("product-", "")) };
  }

  switch (clean) {
    case "home":
      return { name: "home" };
    case "catalog":
      return { name: "catalog" };
    case "cart":
      return { name: "cart" };
    case "favorites":
      return { name: "favorites" };
    case "about":
      return { name: "about" };
    case "delivery":
      return { name: "delivery" };
    case "contacts":
      return { name: "contacts" };
    case "lookbook":
      return { name: "lookbook" };
    case "faq":
      return { name: "faq" };
    case "checkout":
      return { name: "checkout" };
    case "size-guide":
      return { name: "size-guide" };
    case "account":
      return { name: "account" };
    case "login":
      return { name: "login" };
    case "admin":
      return { name: "admin" };
    default:
      return { name: "home" };
  }
}

function pageTitle(page: Page): string {
  switch (page.name) {
    case "home":
      return "NEMKA — Мужская одежда";
    case "catalog":
      return page.category ? `NEMKA — Каталог · ${page.category}` : "NEMKA — Каталог";
    case "product":
      return `NEMKA — Товар ${page.id}`;
    case "cart":
      return "NEMKA — Корзина";
    case "favorites":
      return "NEMKA — Избранное";
    case "about":
      return "NEMKA — О бренде";
    case "delivery":
      return "NEMKA — Доставка и оплата";
    case "contacts":
      return "NEMKA — Контакты";
    case "lookbook":
      return "NEMKA — Lookbook";
    case "faq":
      return "NEMKA — FAQ";
    case "checkout":
      return "NEMKA — Оформление заказа";
    case "size-guide":
      return "NEMKA — Размерная сетка";
    case "account":
      return "NEMKA — Личный кабинет";
    case "login":
      return "NEMKA — Вход";
    case "admin":
      return "NEMKA — Админка";
    default:
      return "NEMKA";
  }
}

export default function App() {
  const [page, setPage] = useState<Page>(() => hashToPage(window.location.hash));
  const [favs, setFavs] = useState<string[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const f = localStorage.getItem("nemka_favs");
      const c = localStorage.getItem("nemka_cart");
      if (f) setFavs(JSON.parse(f));
      if (c) setCart(JSON.parse(c));
    } catch {
      /* ignore */
    }

    const restore = async () => {
      const sid = session.load();
      if (!sid) return;
      const u = await getUserById(sid);
      if (u) setUser(u);
    };
    void restore();

    const onHashChange = () => {
      setPage(hashToPage(window.location.hash));
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    };

    window.addEventListener("hashchange", onHashChange);

    if (!window.location.hash) {
      window.location.hash = pageToHash({ name: "home" });
    }

    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  useEffect(() => {
    localStorage.setItem("nemka_favs", JSON.stringify(favs));
  }, [favs]);

  useEffect(() => {
    localStorage.setItem("nemka_cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    document.title = pageTitle(page);
  }, [page]);

  const navigate = (p: Page) => {
    const nextHash = pageToHash(p);
    setPage(p);
    if (window.location.hash !== nextHash) {
      window.location.hash = nextHash;
    } else {
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    }
  };

  const toggleFav = (id: string) => {
    setFavs((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      showToast(prev.includes(id) ? "Удалено из избранного" : "Добавлено в избранное");
      return next;
    });
  };

  const addToCart = (id: string, size: string) => {
    setCart((prev) => {
      const found = prev.find((x) => x.id === id && x.size === size);
      if (found) return prev.map((x) => (x === found ? { ...x, qty: x.qty + 1 } : x));
      return [...prev, { id, size, qty: 1 }];
    });
    showToast("Товар добавлен в корзину ✓");
  };

  const updateQty = (id: string, size: string, qty: number) => {
    setCart((prev) => prev.map((x) => (x.id === id && x.size === size ? { ...x, qty } : x)));
  };

  const removeFromCart = (id: string, size: string) => {
    setCart((prev) => prev.filter((x) => !(x.id === id && x.size === size)));
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const handleLogin = (u: User) => {
    setUser(u);
    session.save(u.id);
    showToast(`Добро пожаловать, ${u.name}!`);
    navigate({ name: "account" });
  };

  const handleLogout = () => {
    setUser(null);
    session.clear();
    showToast("Вы вышли из аккаунта");
    navigate({ name: "home" });
  };

  const cartCount = useMemo(() => cart.reduce((a, x) => a + x.qty, 0), [cart]);
  const ctx = { navigate, favs, toggleFav, cart, addToCart, updateQty, removeFromCart, showToast, user };

  let content: React.ReactNode = null;
  switch (page.name) {
    case "home":
      content = <HomePage {...ctx} />;
      break;
    case "catalog":
      content = <CatalogPage {...ctx} category={page.category} />;
      break;
    case "product":
      content = <ProductPage {...ctx} id={page.id} />;
      break;
    case "cart":
      content = <CartPage {...ctx} />;
      break;
    case "favorites":
      content = <FavoritesPage {...ctx} />;
      break;
    case "about":
      content = <AboutPage {...ctx} />;
      break;
    case "delivery":
      content = <DeliveryPage {...ctx} />;
      break;
    case "contacts":
      content = <ContactsPage {...ctx} />;
      break;
    case "lookbook":
      content = <LookbookPage {...ctx} />;
      break;
    case "faq":
      content = <FaqPage {...ctx} />;
      break;
    case "checkout":
      content = <CheckoutPage {...ctx} />;
      break;
    case "size-guide":
      content = <SizeGuidePage {...ctx} />;
      break;
    case "account":
      content = <AccountPage user={user} navigate={navigate} onLogout={handleLogout} showToast={showToast} />;
      break;
    case "login":
      content = <LoginPage navigate={navigate} onLogin={handleLogin} showToast={showToast} />;
      break;
    case "admin":
      content = <AdminPage navigate={navigate} showToast={showToast} />;
      break;
  }

  return (
    <div className="min-h-screen flex flex-col bg-paper bg-animated">
      <Header navigate={navigate} cartCount={cartCount} favCount={favs.length} page={page} />
      <main className="flex-1">{content}</main>
      <Footer navigate={navigate} />
      <SupportWidget />
      {toast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[60] bg-accent text-paper px-6 py-3 text-sm shadow-2xl flex items-center gap-2 whitespace-nowrap rounded-lg scale-in font-medium">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M5 12l5 5L20 7" />
          </svg>
          {toast}
        </div>
      )}
    </div>
  );
}
