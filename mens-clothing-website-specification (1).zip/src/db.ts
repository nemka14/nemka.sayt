// ═══════════════════════════════════════════════
//  NEMKA — Локальная база данных (localStorage)
//  Сохраняет ВСЕ данные между сессиями
// ═══════════════════════════════════════════════

export type User = {
  id: string;
  name: string;
  email: string;
  phone: string;
  password: string;
  city: string;
  address: string;
  createdAt: string;
};

export type Order = {
  id: string;
  userId: string;
  items: { productId: string; name: string; size: string; color: string; qty: number; price: number }[];
  total: number;
  shipping: number;
  status: "new" | "processing" | "shipped" | "delivered" | "cancelled";
  delivery: string;
  payment: string;
  comment: string;
  name: string;
  phone: string;
  email: string;
  city: string;
  address: string;
  createdAt: string;
};

export type Review = {
  id: string;
  userId: string;
  userName: string;
  productId: string;
  productName: string;
  rating: number;
  text: string;
  createdAt: string;
};

export type FormSubmission = {
  id: string;
  type: "feedback" | "size-help" | "style-consult" | "wholesale" | "quick-order" | "gift" | "notify" | "subscribe" | "contact";
  data: Record<string, string>;
  createdAt: string;
};

// ═══════ Helpers ═══════

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function getStore<T>(key: string): T[] {
  try {
    const raw = localStorage.getItem(`nemka_${key}`);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function setStore<T>(key: string, data: T[]): void {
  localStorage.setItem(`nemka_${key}`, JSON.stringify(data));
}

// ═══════ USERS ═══════

export function registerUser(name: string, email: string, phone: string, password: string): User | string {
  const users = getStore<User>("users");
  if (users.find(u => u.email === email)) return "Пользователь с таким email уже зарегистрирован";
  const user: User = {
    id: generateId(),
    name, email, phone, password,
    city: "", address: "",
    createdAt: new Date().toISOString(),
  };
  users.push(user);
  setStore("users", users);
  return user;
}

export function loginUser(email: string, password: string): User | string {
  const users = getStore<User>("users");
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) return "Неверный email или пароль";
  return user;
}

export function updateUser(userId: string, data: Partial<User>): User | null {
  const users = getStore<User>("users");
  const idx = users.findIndex(u => u.id === userId);
  if (idx === -1) return null;
  users[idx] = { ...users[idx], ...data };
  setStore("users", users);
  return users[idx];
}

export function getUser(userId: string): User | null {
  return getStore<User>("users").find(u => u.id === userId) || null;
}

export function getAllUsers(): User[] {
  return getStore<User>("users");
}

// ═══════ ORDERS ═══════

export function createOrder(order: Omit<Order, "id" | "createdAt" | "status">): Order {
  const orders = getStore<Order>("orders");
  const newOrder: Order = {
    ...order,
    id: `ORD-${Date.now().toString(36).toUpperCase()}`,
    status: "new",
    createdAt: new Date().toISOString(),
  };
  orders.push(newOrder);
  setStore("orders", orders);
  return newOrder;
}

export function getOrdersByUser(userId: string): Order[] {
  return getStore<Order>("orders").filter(o => o.userId === userId);
}

export function getAllOrders(): Order[] {
  return getStore<Order>("orders");
}

export function updateOrderStatus(orderId: string, status: Order["status"]): Order | null {
  const orders = getStore<Order>("orders");
  const idx = orders.findIndex(o => o.id === orderId);
  if (idx === -1) return null;
  orders[idx].status = status;
  setStore("orders", orders);
  return orders[idx];
}

// ═══════ REVIEWS ═══════

export function addReview(review: Omit<Review, "id" | "createdAt">): Review {
  const reviews = getStore<Review>("reviews");
  const newReview: Review = {
    ...review,
    id: generateId(),
    createdAt: new Date().toISOString(),
  };
  reviews.push(newReview);
  setStore("reviews", reviews);
  return newReview;
}

export function getReviewsByProduct(productId: string): Review[] {
  return getStore<Review>("reviews").filter(r => r.productId === productId);
}

export function getAllReviews(): Review[] {
  return getStore<Review>("reviews");
}

// ═══════ FORM SUBMISSIONS ═══════

export function saveFormSubmission(type: FormSubmission["type"], data: Record<string, string>): FormSubmission {
  const submissions = getStore<FormSubmission>("forms");
  const sub: FormSubmission = {
    id: generateId(),
    type,
    data,
    createdAt: new Date().toISOString(),
  };
  submissions.push(sub);
  setStore("forms", submissions);
  return sub;
}

export function getAllFormSubmissions(): FormSubmission[] {
  return getStore<FormSubmission>("forms");
}

export function getFormsByType(type: FormSubmission["type"]): FormSubmission[] {
  return getStore<FormSubmission>("forms").filter(f => f.type === type);
}

// ═══════ CART (persistent) ═══════

export type CartItem = { id: string; size: string; color: string; qty: number };

export function saveCart(items: CartItem[]): void {
  setStore("cart", items);
}

export function loadCart(): CartItem[] {
  return getStore<CartItem>("cart");
}

// ═══════ FAVORITES (persistent) ═══════

export function saveFavorites(ids: string[]): void {
  localStorage.setItem("nemka_favs", JSON.stringify(ids));
}

export function loadFavorites(): string[] {
  try {
    const raw = localStorage.getItem("nemka_favs");
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

// ═══════ CURRENT SESSION ═══════

export function saveSession(userId: string): void {
  localStorage.setItem("nemka_session", userId);
}

export function loadSession(): string | null {
  return localStorage.getItem("nemka_session");
}

export function clearSession(): void {
  localStorage.removeItem("nemka_session");
}

// ═══════ DB STATS ═══════

export function getDbStats() {
  return {
    users: getStore<User>("users").length,
    orders: getStore<Order>("orders").length,
    reviews: getStore<Review>("reviews").length,
    forms: getStore<FormSubmission>("forms").length,
    totalRevenue: getStore<Order>("orders").reduce((a, o) => a + o.total, 0),
    newOrders: getStore<Order>("orders").filter(o => o.status === "new").length,
    processingOrders: getStore<Order>("orders").filter(o => o.status === "processing").length,
    shippedOrders: getStore<Order>("orders").filter(o => o.status === "shipped").length,
    deliveredOrders: getStore<Order>("orders").filter(o => o.status === "delivered").length,
  };
}
