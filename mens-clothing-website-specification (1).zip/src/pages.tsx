import { useMemo, useState } from "react";
import {
  PRODUCTS, CATEGORIES, REVIEWS, BENEFITS, FAQ, HERO_IMAGES,
  MATERIALS, FITS, STYLES, SEASONS, MESSENGERS, OUTFITS, TOP_CATEGORIES_WEEK,
} from "./data";
import type { Product } from "./data";
import {
  Btn, Icon, ProductCard, Section, QuickOrderModal, FormModal, MessengerIcon,
} from "./components";
import type { Page } from "./components";

import type { User } from "./db";
import * as Repo from "./repository";

type Ctx = {
  navigate: (p: Page) => void;
  favs: string[];
  toggleFav: (id: string) => void;
  cart: { id: string; size: string; qty: number }[];
  addToCart: (id: string, size: string) => void;
  updateQty: (id: string, size: string, qty: number) => void;
  removeFromCart: (id: string, size: string) => void;
  showToast: (msg: string) => void;
  user?: User | null;
};

/* =================== HOME =================== */
export function HomePage({ navigate, favs, toggleFav, showToast }: Ctx) {
  const newProducts = PRODUCTS.filter((p) => p.badge === "NEW").slice(0, 4);
  const hits = PRODUCTS.filter((p) => p.badge === "HIT" || !p.badge).slice(0, 4);
  const [quickProduct, setQuickProduct] = useState<Product | null>(null);
  const [styleForm, setStyleForm] = useState(false);

  const cats = [
    { slug: "coats", title: "Пальто", img: HERO_IMAGES.coats },
    { slug: "shirts", title: "Рубашки", img: HERO_IMAGES.whiteShirt },
    { slug: "jackets", title: "Куртки", img: HERO_IMAGES.corduroy },
    { slug: "blazers", title: "Пиджаки", img: HERO_IMAGES.suits },
    { slug: "tshirts", title: "Футболки", img: HERO_IMAGES.beige },
    { slug: "jeans", title: "Джинсы", img: HERO_IMAGES.pinkShirt },
  ];

  return (
    <>
      {/* ── HERO ─ */}
      <section className="relative bg-paper text-ink overflow-hidden bg-animated">
        <div className="absolute inset-0 bg-gradient-to-br from-transparent via-accent/5 to-transparent rotate-12 scale-150 animate-pulse"></div>
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 grid lg:grid-cols-12 gap-8 lg:gap-12 pt-10 lg:pt-16 pb-16 lg:pb-20 relative z-10">
          <div className="lg:col-span-5 flex flex-col justify-between min-h-[60vh] lg:min-h-[78vh]">
            <p className="text-xs uppercase tracking-[0.3em] text-paper/60">
              Коллекция · AW 26
            </p>
            <div>
              <h1 className="font-display text-[44px] sm:text-6xl lg:text-7xl xl:text-8xl leading-[0.95] mb-6">
                Чистый силуэт.
                <br />
                <span className="italic text-accent-2">Сильный</span> образ.
              </h1>
              <p className="text-paper/70 max-w-md text-base lg:text-lg leading-relaxed mb-10">
                Современная мужская одежда без визуального шума. Плотные ткани, точная посадка и детали, которые видно по качеству.
              </p>
              <div className="flex flex-wrap gap-3">
                <Btn onClick={() => navigate({ name: "catalog" })}>
                  В каталог <Icon name="arrow-right" size={16} />
                </Btn>
                <Btn variant="outline" onClick={() => navigate({ name: "lookbook" })}>
                  Смотреть коллекцию
                </Btn>
              </div>
              {/* Messenger buttons */}
              <div className="flex items-center gap-3 mt-8">
                <span className="text-xs uppercase tracking-[0.2em] text-paper/50">Написать:</span>
                {[MESSENGERS.telegram, MESSENGERS.vk, MESSENGERS.max].map((m) => (
                  <a
                    key={m.name}
                    href={m.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-9 h-9 border border-paper/40 rounded-full flex items-center justify-center hover:bg-paper hover:text-ink transition"
                    title={m.name}
                  >
                    <MessengerIcon name={m.icon} size={15} />
                  </a>
                ))}
              </div>
            </div>
            <div className="hidden lg:flex items-center gap-6 text-xs uppercase tracking-[0.25em] text-paper/40">
              <span>01 — Tailored</span>
              <span>02 — Timeless</span>
              <span>03 — Made well</span>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-12 gap-3 lg:gap-5 min-h-[60vh] lg:min-h-[78vh]">
            <div className="col-span-8 row-span-2 relative overflow-hidden bg-graphite">
              <img src={HERO_IMAGES.blackOutfit} alt="NEMKA AW26" className="w-full h-full object-cover" />
            </div>
            <div className="col-span-4 relative overflow-hidden bg-graphite">
              <img src={HERO_IMAGES.corduroy} alt="" className="w-full h-full object-cover" />
            </div>
            <div className="col-span-4 relative overflow-hidden bg-graphite">
              <img src={HERO_IMAGES.beige} alt="" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* ── PROMO BANNER ── */}
      <section className="bg-accent text-paper">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <p className="text-sm">
            <strong>AW26 уже в каталоге</strong> · Бесплатная доставка от 10 000 ₽ · Промокод <strong>FIRST5</strong> на −5%
          </p>
          <Btn variant="outline" onClick={() => navigate({ name: "catalog" })}>
            Смотреть
          </Btn>
        </div>
      </section>

      {/* ── TOP CATEGORIES WEEK ── */}
      <Section eyebrow="Популярное на этой неделе" title="Топ категории">
        <div className="grid md:grid-cols-3 gap-4 lg:gap-6">
          {TOP_CATEGORIES_WEEK.map((c) => (
            <button
              key={c.slug}
              onClick={() => navigate({ name: "catalog", category: c.slug })}
              className="group relative aspect-[4/5] overflow-hidden text-left"
            >
              <img src={c.img} alt={c.title} className="absolute inset-0 w-full h-full object-cover zoom-img" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent" />
              <div className="relative h-full flex flex-col justify-end p-6 text-paper">
                <p className="text-xs uppercase tracking-[0.25em] text-paper/70">{c.subtitle}</p>
                <h3 className="font-display text-3xl lg:text-4xl">{c.title}</h3>
                <span className="mt-2 text-xs uppercase tracking-[0.2em] flex items-center gap-1 group-hover:text-accent-2 transition">
                  Смотреть <Icon name="arrow-right" size={14} />
                </span>
              </div>
            </button>
          ))}
        </div>
      </Section>

      {/* ── CATEGORIES ── */}
      <Section eyebrow="Что носим" title="Категории">
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 lg:gap-5">
          {cats.map((c) => (
            <button
              key={c.slug}
              onClick={() => navigate({ name: "catalog", category: c.slug })}
              className="group block text-left"
            >
              <div className="aspect-[3/4] overflow-hidden bg-cream relative">
                <img src={c.img} alt={c.title} className="w-full h-full object-cover zoom-img" loading="lazy" />
              </div>
              <div className="pt-3 flex items-center justify-between">
                <span className="text-sm uppercase tracking-[0.18em]">{c.title}</span>
                <Icon name="arrow-right" size={14} />
              </div>
            </button>
          ))}
        </div>
      </Section>

      {/* ── NEW COLLECTION SPLIT ── */}
      <section className="bg-cream">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-16 lg:py-24 grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5">
            <p className="text-xs uppercase tracking-[0.3em] text-ash mb-4">Новая коллекция</p>
            <h2 className="font-display text-4xl lg:text-6xl leading-[0.95] mb-6">
              Спокойная сила <em className="text-accent">осени</em>.
            </h2>
            <p className="text-ash text-base lg:text-lg leading-relaxed mb-8 max-w-md">
              Шерсть, плотный хлопок, мягкая фланель. Палитра, в которой каждая вещь работает с любой другой.
            </p>
            <Btn variant="ghost" onClick={() => navigate({ name: "catalog" })}>
              Смотреть AW26
            </Btn>
          </div>
          <div className="lg:col-span-7 grid grid-cols-2 gap-3 lg:gap-5">
            <div className="aspect-[3/4] overflow-hidden">
              <img src={HERO_IMAGES.whiteJacket} alt="" className="w-full h-full object-cover" />
            </div>
            <div className="aspect-[3/4] overflow-hidden mt-10">
              <img src={HERO_IMAGES.whiteShirt} alt="" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* ── NEW PRODUCTS ── */}
      <Section eyebrow="Только что приехало" title="Новинки">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10 lg:gap-x-6">
          {newProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onOpen={() => navigate({ name: "product", id: p.id })}
              onToggleFav={() => toggleFav(p.id)}
              isFav={favs.includes(p.id)}
              onQuickOrder={() => setQuickProduct(p)}
            />
          ))}
        </div>
        <div className="mt-12 flex justify-center">
          <Btn variant="ghost" onClick={() => navigate({ name: "catalog" })}>
            Смотреть всё <Icon name="arrow-right" size={16} />
          </Btn>
        </div>
      </Section>

      {/* ── QUOTE / EDITORIAL ── */}
      <section className="relative h-[70vh] lg:h-[80vh] overflow-hidden">
        <img src={HERO_IMAGES.suits} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-ink/55" />
        <div className="relative h-full flex items-center justify-center text-center text-paper px-5">
          <div className="max-w-3xl">
            <p className="text-xs uppercase tracking-[0.4em] text-paper/70 mb-6">Манифест бренда</p>
            <h2 className="font-display italic text-3xl md:text-5xl lg:text-6xl leading-tight">
              «Одежда, которая держит форму и характер. Без шума, без лишнего.»
            </h2>
          </div>
        </div>
      </section>

      {/* ── ПОДОБРАТЬ ОБРАЗ ── */}
      <section className="bg-ink text-paper">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-16 lg:py-24">
          <p className="text-xs uppercase tracking-[0.3em] text-paper/50 mb-3">Готовые комплекты</p>
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-12">
            <h2 className="font-display text-3xl md:text-5xl lg:text-6xl leading-[0.95]">
              Подобрать образ
            </h2>
            <button
              onClick={() => setStyleForm(true)}
              className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] border border-paper/40 px-5 py-3 hover:bg-paper hover:text-ink transition self-start"
            >
              <Icon name="shirt" size={16} /> Консультация стилиста · бесплатно
            </button>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {OUTFITS.map((o, i) => {
              const items = o.items.map((id) => PRODUCTS.find((p) => p.id === id)).filter(Boolean) as Product[];
              return (
                <div key={i} className="border border-paper/15 overflow-hidden">
                  <div className="aspect-[4/5] relative overflow-hidden">
                    <img src={o.img} alt={o.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="font-display text-2xl">{o.name}</h3>
                      <p className="text-xs text-paper/70 mt-1">{o.desc}</p>
                    </div>
                  </div>
                  <div className="p-5 space-y-3">
                    {items.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => navigate({ name: "product", id: p.id })}
                        className="flex items-center gap-3 w-full text-left hover:text-accent-2 transition"
                      >
                        <img src={p.images[0]} className="w-10 h-12 object-cover" alt="" />
                        <div className="flex-1 min-w-0">
                          <span className="text-sm truncate block">{p.name}</span>
                        </div>
                        <span className="text-sm shrink-0">{p.price.toLocaleString("ru")} ₽</span>
                      </button>
                    ))}
                    <div className="border-t border-paper/15 pt-3 text-right text-sm">
                      Комплект · {items.reduce((a, p) => a + p.price, 0).toLocaleString("ru")} ₽
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── HITS ── */}
      <Section eyebrow="Лучшее у клиентов" title="Хиты продаж">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10 lg:gap-x-6">
          {hits.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onOpen={() => navigate({ name: "product", id: p.id })}
              onToggleFav={() => toggleFav(p.id)}
              isFav={favs.includes(p.id)}
              onQuickOrder={() => setQuickProduct(p)}
            />
          ))}
        </div>
      </Section>

      {/* ── BENEFITS ── */}
      <section className="bg-cream border-y border-ink/10">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-16 lg:py-24">
          <p className="text-xs uppercase tracking-[0.3em] text-ash mb-3">Почему NEMKA</p>
          <h2 className="font-display text-3xl md:text-5xl lg:text-6xl leading-[0.95] mb-12 max-w-3xl">
            Внимание к деталям. Уважение ко времени.
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
            {BENEFITS.map((b, i) => (
              <div key={i} className="border-t-2 border-accent pt-6">
                <div className="text-accent-2 font-display text-2xl mb-4">0{i + 1}</div>
                <h3 className="text-lg uppercase tracking-[0.12em] mb-2">{b.title}</h3>
                <p className="text-ash leading-relaxed">{b.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SIZE & FIT BLOCK ── */}
      <Section eyebrow="Размер и посадка" title="Как понять свой размер">
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <p className="text-ash leading-relaxed mb-6">
              В карточке каждого товара есть размерная сетка с точными замерами в сантиметрах. Если сомневаетесь — напишите стилисту, поможем за 15 минут.
            </p>
            <div className="grid grid-cols-2 gap-4 mb-6">
              {[
                { label: "Рост", values: "165–195 см" },
                { label: "Грудь", values: "86–116 см" },
                { label: "Талия", values: "70–100 см" },
                { label: "Бёдра", values: "92–116 см" },
              ].map((m) => (
                <div key={m.label} className="bg-cream p-4">
                  <p className="text-xs uppercase tracking-[0.2em] text-ash">{m.label}</p>
                  <p className="text-lg font-semibold mt-1">{m.values}</p>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-3">
              <Btn variant="ghost" onClick={() => navigate({ name: "size-guide" })}>
                <Icon name="ruler" size={16} /> Таблица размеров
              </Btn>
              <Btn variant="ghost" onClick={() => navigate({ name: "contacts" })}>
                Помочь с размером
              </Btn>
            </div>
          </div>
          <div className="aspect-[4/3] bg-cream overflow-hidden">
            <img src={HERO_IMAGES.profile} alt="" className="w-full h-full object-cover" />
          </div>
        </div>
      </Section>

      {/* ── LOOKBOOK PREVIEW ── */}
      <Section eyebrow="Образы" title="Lookbook AW26">
        <div className="grid grid-cols-12 gap-3 lg:gap-5">
          <div className="col-span-12 lg:col-span-5 aspect-[3/4] overflow-hidden">
            <img src={HERO_IMAGES.coats} alt="" className="w-full h-full object-cover zoom-img" />
          </div>
          <div className="col-span-6 lg:col-span-4 aspect-[3/4] overflow-hidden lg:mt-16">
            <img src={HERO_IMAGES.kurta} alt="" className="w-full h-full object-cover zoom-img" />
          </div>
          <div className="col-span-6 lg:col-span-3 aspect-[3/4] overflow-hidden">
            <img src={HERO_IMAGES.profile} alt="" className="w-full h-full object-cover zoom-img" />
          </div>
        </div>
        <div className="mt-10 text-center">
          <Btn variant="ghost" onClick={() => navigate({ name: "lookbook" })}>
            Смотреть весь lookbook
          </Btn>
        </div>
      </Section>

      {/* ── DELIVERY STRIP ── */}
      <section className="border-y border-ink/10 bg-paper">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-12 grid md:grid-cols-3 gap-8 text-center md:text-left">
          {[
            { ic: "truck", t: "Доставка по России", d: "Курьером и в пункт выдачи · 1–3 дня" },
            { ic: "check", t: "Оплата как удобно", d: "Картой, СБП или при получении" },
            { ic: "heart", t: "Возврат 14 дней", d: "Без объяснения причин" },
          ].map((x, i) => (
            <div key={i} className="flex md:items-center gap-5 justify-center md:justify-start">
              <div className="w-12 h-12 border border-ink rounded-full flex items-center justify-center">
                <Icon name={x.ic} size={20} />
              </div>
              <div>
                <div className="text-sm uppercase tracking-[0.18em] mb-1">{x.t}</div>
                <div className="text-ash text-sm">{x.d}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── REVIEWS WITH PHOTOS ── */}
      <Section eyebrow="Отзывы" title="Что говорят клиенты">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {REVIEWS.map((r, i) => (
            <div key={i} className="border border-ink/15 bg-paper overflow-hidden">
              <div className="aspect-[4/3] overflow-hidden bg-cream">
                <img src={r.photo} alt={r.product} className="w-full h-full object-cover" loading="lazy" />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-0.5 text-accent-2 mb-3">
                  {Array.from({ length: r.rating }).map((_, j) => (
                    <Icon key={j} name="star" size={14} />
                  ))}
                </div>
                <p className="text-[15px] leading-relaxed mb-4">«{r.text}»</p>
                <div className="flex items-center justify-between text-xs text-ash uppercase tracking-[0.18em]">
                  <span>{r.name} · {r.city}</span>
                  <span className="text-accent">{r.product}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* ── SUPPORT BLOCK ── */}
      <section className="bg-ink text-paper">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-16 lg:py-20">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-paper/50 mb-3">Поддержка</p>
              <h2 className="font-display text-3xl lg:text-5xl leading-tight mb-4">
                Всегда на связи. <em className="text-accent-2">Ответим за 15 мин.</em>
              </h2>
              <p className="text-paper/70 leading-relaxed mb-8">
                Вопросы по размеру, составу или доставке? Поможем через любой удобный канал. Работаем ежедневно, 09:00–22:00.
              </p>
              <div className="grid grid-cols-3 gap-3">
                {[MESSENGERS.telegram, MESSENGERS.vk, MESSENGERS.max].map((m) => (
                  <a
                    key={m.name}
                    href={m.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col items-center gap-2 py-5 border border-paper/20 hover:bg-paper hover:text-ink transition rounded"
                  >
                    <MessengerIcon name={m.icon} size={24} />
                    <span className="text-xs uppercase tracking-[0.2em]">{m.name}</span>
                  </a>
                ))}
              </div>
              <div className="flex flex-wrap gap-4 mt-6 text-sm">
                <a href="tel:+74951234567" className="hover:text-accent-2">📞 +7 495 123-45-67</a>
                <a href="mailto:mahmudovv.14.00@gmail.com" className="hover:text-accent-2">✉ mahmudovv.14.00@gmail.com</a>
              </div>
            </div>
            <div className="bg-paper/5 border border-paper/10 rounded-lg p-6 lg:p-8">
              <p className="text-xs uppercase tracking-[0.3em] text-paper/50 mb-4">Быстрый вопрос</p>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const form = e.target as HTMLFormElement;
                  const data = Object.fromEntries(new FormData(form).entries()) as Record<string, string>;
                  void Repo.saveFormSubmission("contact", data);
                  showToast("Сообщение отправлено! Ответим в течение 15 минут.");
                  form.reset();
                }}
                className="space-y-4"
              >
                <input name="name" required placeholder="Ваше имя" className="w-full bg-transparent border border-paper/20 px-4 py-3 outline-none focus:border-paper/60 text-paper placeholder:text-paper/40" />
                <input name="phone" required type="tel" placeholder="Телефон или Telegram" className="w-full bg-transparent border border-paper/20 px-4 py-3 outline-none focus:border-paper/60 text-paper placeholder:text-paper/40" />
                <textarea name="question" required rows={3} placeholder="Ваш вопрос" className="w-full bg-transparent border border-paper/20 px-4 py-3 outline-none focus:border-paper/60 text-paper placeholder:text-paper/40" />
                <Btn variant="outline" full type="submit">
                  <Icon name="send" size={16} /> Отправить
                </Btn>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* ── NEWSLETTER ── */}
      <section className="bg-cream">
        <div className="max-w-[1100px] mx-auto px-5 lg:px-10 py-20 text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-ash mb-4">Письма</p>
          <h2 className="font-display text-4xl lg:text-6xl leading-[0.95] mb-6">
            Без спама. <em className="text-accent">Только дело.</em>
          </h2>
          <p className="text-ash max-w-xl mx-auto mb-8">
            Раз в месяц — лукбук, новинки и закрытые скидки. Подпишитесь → −5% на первый заказ.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.target as HTMLFormElement;
              const data = Object.fromEntries(new FormData(form).entries()) as Record<string, string>;
              void Repo.saveFormSubmission("subscribe", data);
              showToast("Спасибо! Промокод FIRST5 отправлен на почту.");
              form.reset();
            }}
            className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto"
          >
            <input
              required
              name="email"
              type="email"
              placeholder="E-mail"
              className="flex-1 px-5 py-4 bg-paper border border-ink/20 outline-none focus:border-ink"
            />
            <Btn type="submit">Подписаться</Btn>
          </form>
        </div>
      </section>

      {/* ── QUICK ORDER MODAL ── */}
      {quickProduct && (
        <QuickOrderModal
          product={quickProduct}
          onClose={() => setQuickProduct(null)}
          onSubmitData={(data) => { void Repo.saveFormSubmission("quick-order", data); }}
          onSuccess={() => { setQuickProduct(null); showToast("Заявка принята! Перезвоним через 15 минут."); }}
        />
      )}

      {/* ── STYLE CONSULTATION MODAL ── */}
      {styleForm && (
        <FormModal
          title="Консультация стилиста"
          subtitle="Расскажите о себе — подберём комплект под ваш стиль, бюджет и ситуацию. Бесплатно."
          fields={[
            { name: "name", label: "Имя", required: true },
            { name: "phone", label: "Телефон или Telegram", type: "tel", required: true },
            { name: "occasion", label: "Для какого случая?", options: ["Офис / деловой", "Повседневный", "Свидание / выход", "Подарок", "Другое"] },
            { name: "budget", label: "Бюджет", options: ["до 10 000 ₽", "10 000 – 30 000 ₽", "30 000 – 60 000 ₽", "без ограничений"] },
            { name: "comment", label: "Что ещё важно", textarea: true },
          ]}
          onClose={() => setStyleForm(false)}
          onSubmitData={(data) => { void Repo.saveFormSubmission("style-consult", data); }}
          onSuccess={() => { setStyleForm(false); showToast("Заявка отправлена! Стилист свяжется в течение часа."); }}
          submitLabel="Получить рекомендацию"
        />
      )}
    </>
  );
}

/* =================== CATALOG =================== */
export function CatalogPage({ navigate, favs, toggleFav, category, showToast }: Ctx & { category?: string }) {
  const [activeCat, setActiveCat] = useState<string>(category ?? "all");
  const [sort, setSort] = useState<"popular" | "price-asc" | "price-desc" | "new">("popular");
  const [sizeFilter, setSizeFilter] = useState<string[]>([]);
  const [priceMax, setPriceMax] = useState(50000);
  const [materialFilter, setMaterialFilter] = useState<string[]>([]);
  const [fitFilter, setFitFilter] = useState<string[]>([]);
  const [styleFilter, setStyleFilter] = useState<string[]>([]);
  const [seasonFilter, setSeasonFilter] = useState<string[]>([]);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [newOnly, setNewOnly] = useState(false);
  const [saleOnly, setSaleOnly] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [quickProduct, setQuickProduct] = useState<Product | null>(null);
  const [quickView, setQuickView] = useState<Product | null>(null);
  const [visibleCount, setVisibleCount] = useState(24);

  const filtered = useMemo(() => {
    let list = PRODUCTS.filter(
      (p) => (activeCat === "all" || p.category === activeCat) && p.price <= priceMax
    );
    if (sizeFilter.length) list = list.filter((p) => p.sizes.some((s) => sizeFilter.includes(s)));
    if (materialFilter.length) list = list.filter((p) => materialFilter.includes(p.materialTag));
    if (fitFilter.length) list = list.filter((p) => fitFilter.includes(p.fit));
    if (styleFilter.length) list = list.filter((p) => styleFilter.includes(p.style));
    if (seasonFilter.length) list = list.filter((p) => seasonFilter.includes(p.season));
    if (inStockOnly) list = list.filter((p) => p.inStock);
    if (newOnly) list = list.filter((p) => p.badge === "NEW");
    if (saleOnly) list = list.filter((p) => p.badge === "SALE");
    switch (sort) {
      case "price-asc": list = [...list].sort((a, b) => a.price - b.price); break;
      case "price-desc": list = [...list].sort((a, b) => b.price - a.price); break;
      case "new": list = [...list].sort((a) => (a.badge === "NEW" ? -1 : 1)); break;
    }
    return list;
  }, [activeCat, sort, sizeFilter, priceMax, materialFilter, fitFilter, styleFilter, seasonFilter, inStockOnly, newOnly, saleOnly]);

  const allSizes = ["XS", "S", "M", "L", "XL", "XXL"];
  const activeFilterCount = [sizeFilter.length, materialFilter.length, fitFilter.length, styleFilter.length, seasonFilter.length, inStockOnly ? 1 : 0, newOnly ? 1 : 0, saleOnly ? 1 : 0].reduce((a, b) => a + b, 0);

  const resetFilters = () => {
    setSizeFilter([]);
    setMaterialFilter([]);
    setFitFilter([]);
    setStyleFilter([]);
    setSeasonFilter([]);
    setInStockOnly(false);
    setNewOnly(false);
    setSaleOnly(false);
    setPriceMax(50000);
  };

  const filterPanel = (
    <div className="space-y-8">
      {activeFilterCount > 0 && (
        <button onClick={resetFilters} className="text-xs uppercase tracking-[0.2em] text-accent underline underline-offset-4">
          Сбросить все фильтры
        </button>
      )}
      {/* Size */}
      <FilterSection title="Размер">
        <div className="flex flex-wrap gap-2">
          {allSizes.map((s) => {
            const active = sizeFilter.includes(s);
            return (
              <button
                key={s}
                onClick={() => setSizeFilter(active ? sizeFilter.filter((x) => x !== s) : [...sizeFilter, s])}
                className={`w-11 h-11 border text-sm transition ${active ? "bg-ink text-paper border-ink" : "border-ink/30 hover:border-ink"}`}
              >{s}</button>
            );
          })}
        </div>
      </FilterSection>
      {/* Price */}
      <FilterSection title={`Цена · до ${priceMax.toLocaleString("ru")} ₽`}>
        <input type="range" min={3000} max={50000} step={500} value={priceMax}
          onChange={(e) => setPriceMax(parseInt(e.target.value))}
          className="w-full accent-[var(--color-accent)]" />
      </FilterSection>
      {/* Material */}
      <FilterSection title="Материал">
        <div className="space-y-2 text-sm">
          {MATERIALS.map((m) => (
            <label key={m} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={materialFilter.includes(m)}
                onChange={() => setMaterialFilter(materialFilter.includes(m) ? materialFilter.filter((x) => x !== m) : [...materialFilter, m])}
                className="accent-[var(--color-accent)]" />
              {m}
            </label>
          ))}
        </div>
      </FilterSection>
      {/* Fit */}
      <FilterSection title="Посадка">
        <div className="space-y-2 text-sm">
          {FITS.map((f) => (
            <label key={f} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={fitFilter.includes(f)}
                onChange={() => setFitFilter(fitFilter.includes(f) ? fitFilter.filter((x) => x !== f) : [...fitFilter, f])}
                className="accent-[var(--color-accent)]" />
              {f}
            </label>
          ))}
        </div>
      </FilterSection>
      {/* Style */}
      <FilterSection title="Стиль">
        <div className="space-y-2 text-sm">
          {STYLES.map((s) => (
            <label key={s} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={styleFilter.includes(s)}
                onChange={() => setStyleFilter(styleFilter.includes(s) ? styleFilter.filter((x) => x !== s) : [...styleFilter, s])}
                className="accent-[var(--color-accent)]" />
              {s}
            </label>
          ))}
        </div>
      </FilterSection>
      {/* Season */}
      <FilterSection title="Сезон">
        <div className="space-y-2 text-sm">
          {SEASONS.map((s) => (
            <label key={s} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={seasonFilter.includes(s)}
                onChange={() => setSeasonFilter(seasonFilter.includes(s) ? seasonFilter.filter((x) => x !== s) : [...seasonFilter, s])}
                className="accent-[var(--color-accent)]" />
              {s}
            </label>
          ))}
        </div>
      </FilterSection>
      {/* Quick toggles */}
      <FilterSection title="Дополнительно">
        <div className="space-y-2 text-sm">
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={inStockOnly} onChange={() => setInStockOnly(!inStockOnly)} className="accent-[var(--color-accent)]" />
            В наличии
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={newOnly} onChange={() => setNewOnly(!newOnly)} className="accent-[var(--color-accent)]" />
            Только новинки
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={saleOnly} onChange={() => setSaleOnly(!saleOnly)} className="accent-[var(--color-accent)]" />
            Со скидкой
          </label>
        </div>
      </FilterSection>
      {/* Color */}
      <FilterSection title="Цвет">
        <div className="flex flex-wrap gap-2">
          {[
            { hex: "#0a0a0a", name: "Чёрный" },
            { hex: "#ffffff", name: "Белый" },
            { hex: "#6b6657", name: "Оливковый" },
            { hex: "#2d4a3a", name: "Зелёный" },
            { hex: "#5a3a2a", name: "Коричневый" },
            { hex: "#1f2a3a", name: "Индиго" },
          ].map((c) => (
            <button
              key={c.hex}
              style={{ background: c.hex }}
              className="w-7 h-7 rounded-full border border-black/15"
              title={c.name}
            />
          ))}
        </div>
      </FilterSection>
    </div>
  );

  return (
    <>
      {/* Header strip */}
      <section className="border-b border-ink/10">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 pt-12 pb-8">
          <p className="text-xs uppercase tracking-[0.3em] text-ash mb-3">Каталог</p>
          <h1 className="font-display text-4xl lg:text-6xl leading-[0.95]">
            {CATEGORIES.find((c) => c.slug === activeCat)?.title ?? "Все"}{" "}
            <span className="text-ash text-2xl lg:text-3xl align-middle">· {filtered.length}</span>
          </h1>
        </div>
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 pb-4 flex gap-3 overflow-x-auto no-scrollbar">
          {CATEGORIES.map((c) => (
            <button key={c.slug} onClick={() => setActiveCat(c.slug)}
              className={`shrink-0 px-4 py-2 text-xs uppercase tracking-[0.18em] border rounded-full transition ${
                activeCat === c.slug ? "bg-ink text-paper border-ink" : "border-ink/20 hover:border-ink"}`}
            >{c.title}</button>
          ))}
        </div>
      </section>

      <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-10 grid lg:grid-cols-12 gap-10">
        {/* FILTERS DESKTOP */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-28 self-start max-h-[calc(100vh-8rem)] overflow-auto pr-4">
          {filterPanel}
        </aside>

        <div className="lg:col-span-9">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={() => setFilterOpen(true)}
              className="lg:hidden flex items-center gap-2 text-xs uppercase tracking-[0.2em] border border-ink px-4 py-2"
            >
              <Icon name="filter" size={16} />
              Фильтры{activeFilterCount > 0 && ` · ${activeFilterCount}`}
            </button>
            <div className="flex items-center gap-2 ml-auto text-xs">
              <span className="uppercase tracking-[0.18em] text-ash">Сортировка:</span>
              <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)}
                className="bg-transparent border-b border-ink/30 py-1 outline-none uppercase tracking-[0.18em] text-xs">
                <option value="popular">По популярности</option>
                <option value="new">Новинки</option>
                <option value="price-asc">Цена: ↑</option>
                <option value="price-desc">Цена: ↓</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-10 lg:gap-x-6">
            {filtered.slice(0, visibleCount).map((p) => (
              <ProductCard key={p.id} product={p}
                onOpen={() => navigate({ name: "product", id: p.id })}
                onToggleFav={() => toggleFav(p.id)}
                isFav={favs.includes(p.id)}
                onQuickOrder={() => setQuickProduct(p)}
              />
            ))}
          </div>

          {filtered.length > visibleCount && (
            <div className="mt-12 text-center">
              <p className="text-sm text-ash mb-4">
                Показано {visibleCount} из {filtered.length} товаров
              </p>
              <Btn variant="ghost" onClick={() => setVisibleCount((v) => v + 24)}>
                Показать ещё {Math.min(24, filtered.length - visibleCount)}
              </Btn>
            </div>
          )}

          {filtered.length > 0 && filtered.length <= visibleCount && (
            <div className="mt-10 text-center text-sm text-ash">
              Показаны все товары · {filtered.length} шт.
            </div>
          )}

          {filtered.length === 0 && (
            <div className="py-24 text-center text-ash">
              <p className="mb-4">По выбранным фильтрам ничего не найдено.</p>
              <Btn variant="ghost" onClick={resetFilters}>Сбросить фильтры</Btn>
            </div>
          )}
        </div>
      </div>

      {/* MOBILE FILTERS */}
      {filterOpen && (
        <div className="fixed inset-0 z-50 bg-paper p-6 lg:hidden overflow-auto">
          <div className="flex justify-between items-center mb-8">
            <span className="text-xs uppercase tracking-[0.3em]">Фильтры</span>
            <button onClick={() => setFilterOpen(false)} aria-label="Закрыть"><Icon name="close" /></button>
          </div>
          {filterPanel}
          <div className="mt-8 sticky bottom-0 bg-paper py-4 border-t border-ink/10">
            <Btn full onClick={() => setFilterOpen(false)}>Показать ({filtered.length})</Btn>
          </div>
        </div>
      )}

      {/* Quick View */}
      {quickView && (
        <div className="fixed inset-0 z-50 bg-ink/60 flex items-center justify-center p-4" onClick={() => setQuickView(null)}>
          <div className="bg-paper w-full max-w-3xl max-h-[90vh] overflow-auto p-6 lg:p-8 grid md:grid-cols-2 gap-6 relative" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setQuickView(null)} className="absolute top-4 right-4"><Icon name="close" /></button>
            <img src={quickView.images[0]} className="w-full aspect-[3/4] object-cover bg-cream" alt="" />
            <div>
              <p className="font-display text-2xl mb-2">{quickView.name}</p>
              <p className="text-xl font-semibold mb-4">{quickView.price.toLocaleString("ru")} ₽</p>
              <p className="text-ash text-sm mb-4">{quickView.description}</p>
              <Btn onClick={() => { setQuickView(null); navigate({ name: "product", id: quickView.id }); }}>
                Подробнее
              </Btn>
            </div>
          </div>
        </div>
      )}

      {quickProduct && (
        <QuickOrderModal product={quickProduct}
          onClose={() => setQuickProduct(null)}
          onSubmitData={(data) => { void Repo.saveFormSubmission("quick-order", data); }}
          onSuccess={() => { setQuickProduct(null); showToast("Заявка принята! Перезвоним через 15 минут."); }}
        />
      )}
    </>
  );
}

function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-[0.25em] mb-3">{title}</p>
      {children}
    </div>
  );
}

/* =================== PRODUCT =================== */
export function ProductPage({ id, navigate, favs, toggleFav, addToCart, showToast }: Ctx & { id: string }) {
  const product = PRODUCTS.find((p) => p.id === id);
  const [size, setSize] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState(0);
  const [activeImg, setActiveImg] = useState(0);
  const [openSection, setOpenSection] = useState<string | null>("desc");
  const [quickOrder, setQuickOrder] = useState(false);
  const [sizeHelp, setSizeHelp] = useState(false);
  const [notifyForm, setNotifyForm] = useState(false);
  const [giftForm, setGiftForm] = useState(false);

  if (!product) return (
    <div className="max-w-3xl mx-auto px-5 py-32 text-center">
      <p className="mb-6">Товар не найден.</p>
      <Btn onClick={() => navigate({ name: "catalog" })}>В каталог</Btn>
    </div>
  );

  const pairsProducts = product.pairsWith.map((pid) => PRODUCTS.find((p) => p.id === pid)).filter(Boolean) as Product[];
  const recs = PRODUCTS.filter((p) => p.id !== id && p.category === product.category).slice(0, 4);
  const toggleS = (s: string) => setOpenSection(openSection === s ? null : s);

  return (
    <>
      <div className="max-w-[1400px] mx-auto px-5 lg:px-10 pt-6">
        <button onClick={() => navigate({ name: "catalog", category: product.category })}
          className="text-xs uppercase tracking-[0.25em] text-ash hover:text-ink">
          ← Назад в каталог
        </button>
      </div>

      <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-8 lg:py-12 grid lg:grid-cols-12 gap-10">
        {/* IMAGES */}
        <div className="lg:col-span-7 grid grid-cols-12 gap-3 lg:gap-4">
          <div className="hidden lg:flex lg:col-span-2 flex-col gap-3">
            {product.images.map((src, i) => (
              <button key={i} onClick={() => setActiveImg(i)}
                className={`aspect-[3/4] overflow-hidden border ${activeImg === i ? "border-ink" : "border-transparent"}`}>
                <img src={src} className="w-full h-full object-cover" alt="" />
              </button>
            ))}
          </div>
          <div className="col-span-12 lg:col-span-10 aspect-[3/4] overflow-hidden bg-cream relative">
            <img src={product.images[activeImg]} alt={product.name} className="w-full h-full object-cover" />
            {/* Dynamic visual overlay to change product rendering color based on color button selection */}
            <div 
              style={{ backgroundColor: product.colors[selectedColor]?.hex, mixBlendMode: "multiply" }} 
              className="absolute inset-0 opacity-25 pointer-events-none transition-all duration-300" 
            />
            <div 
              style={{ backgroundColor: product.colors[selectedColor]?.hex, mixBlendMode: "color" }} 
              className="absolute inset-0 opacity-20 pointer-events-none transition-all duration-300" 
            />
          </div>
          <div className="col-span-12 flex gap-2 lg:hidden overflow-x-auto no-scrollbar">
            {product.images.map((src, i) => (
              <button key={i} onClick={() => setActiveImg(i)}
                className={`shrink-0 w-20 aspect-[3/4] border ${activeImg === i ? "border-ink" : "border-transparent"}`}>
                <img src={src} className="w-full h-full object-cover" alt="" />
              </button>
            ))}
          </div>
        </div>

        {/* INFO */}
        <div className="lg:col-span-5 lg:sticky lg:top-28 self-start">
          {product.badge && (
            <span className="text-[10px] uppercase tracking-[0.3em] text-accent">
              {product.badge === "SALE" ? "Скидка" : product.badge === "NEW" ? "Новинка" : "Бестселлер"}
            </span>
          )}
          <h1 className="font-display text-3xl lg:text-5xl leading-tight mt-2 mb-4">{product.name}</h1>
          <div className="flex items-baseline gap-3 mb-2">
            <span className="text-2xl font-semibold">{product.price.toLocaleString("ru")} ₽</span>
            {product.oldPrice && <span className="text-ash line-through">{product.oldPrice.toLocaleString("ru")} ₽</span>}
          </div>
          <div className="flex items-center gap-4 mb-6 text-xs text-ash">
            <span>{product.fit} крой</span>
            <span>·</span>
            <span>{product.style}</span>
            <span>·</span>
            <span>{product.season}</span>
          </div>

          {/* Color */}
          <div className="mb-6">
            <div className="flex justify-between text-xs uppercase tracking-[0.2em] mb-3">
              <span>Цвет · <span className="text-ink font-medium normal-case">{product.colors[selectedColor]?.name}</span></span>
              <span className="text-ash">{product.colors.length} {product.colors.length > 4 ? "цветов" : "варианта"}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.colors.map((c, i) => (
                <button key={i} onClick={() => setSelectedColor(i)}
                  style={{ background: c.hex }}
                  className={`w-10 h-10 rounded-full border-2 transition-all ${
                    selectedColor === i
                      ? "border-ink ring-2 ring-ink ring-offset-2 scale-110"
                      : "border-black/15 hover:border-black/40"
                  }`}
                  title={c.name}>
                  {selectedColor === i && (
                    <svg className="w-4 h-4 mx-auto" viewBox="0 0 24 24" fill="none" stroke={c.hex === "#ffffff" || c.hex === "#f5f0e8" || c.hex === "#e8dcc8" ? "#0a0a0a" : "#ffffff"} strokeWidth="3">
                      <path d="M5 12l5 5L20 7" />
                    </svg>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Size */}
          <div className="mb-6">
            <div className="flex justify-between text-xs uppercase tracking-[0.2em] mb-3">
              <span>Размер</span>
              <div className="flex gap-3">
                <button onClick={() => setSizeHelp(true)} className="underline underline-offset-2 hover:text-accent">
                  Помочь с размером
                </button>
                <button onClick={() => navigate({ name: "size-guide" })} className="underline underline-offset-2 hover:text-accent">
                  Размерная сетка
                </button>
              </div>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {product.sizes.map((s) => (
                <button key={s} onClick={() => setSize(s)}
                  className={`py-3 border text-sm transition ${size === s ? "bg-ink text-paper border-ink" : "border-ink/25 hover:border-ink"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Stock */}
          <div className="text-xs flex items-center gap-2 mb-6">
            <span className={`w-2 h-2 rounded-full ${product.inStock ? "bg-accent" : "bg-ash"}`} />
            {product.inStock ? "В наличии · отправим завтра" : "Временно нет в наличии"}
          </div>

          {/* Buttons */}
          <div className="flex gap-2 mb-3">
            {product.inStock ? (
              <Btn full onClick={() => {
                if (!size) { alert("Пожалуйста, выберите размер"); return; }
                addToCart(product.id, size);
                showToast(`${product.colors[selectedColor]?.name}, размер ${size} — добавлен`);
              }}>
                В корзину · {product.colors[selectedColor]?.name}
              </Btn>
            ) : (
              <Btn full onClick={() => setNotifyForm(true)}>
                Сообщить о наличии
              </Btn>
            )}
            <button onClick={() => toggleFav(product.id)}
              className="border border-ink p-4 hover:bg-ink hover:text-paper transition" aria-label="В избранное">
              <Icon name={favs.includes(product.id) ? "heart-fill" : "heart"} />
            </button>
          </div>
          {/* Quick order & extras */}
          <div className="grid grid-cols-3 gap-2 mb-6">
            <button onClick={() => setQuickOrder(true)}
              className="text-center text-xs uppercase tracking-[0.15em] border border-ink/25 py-3 hover:bg-ink hover:text-paper transition">
              Быстрый заказ
            </button>
            <button onClick={() => setGiftForm(true)}
              className="text-center text-xs uppercase tracking-[0.15em] border border-ink/25 py-3 hover:bg-ink hover:text-paper transition">
              🎁 В подарок
            </button>
            <a href={MESSENGERS.telegram.url} target="_blank" rel="noopener noreferrer"
              className="flex items-center justify-center gap-1 text-xs uppercase tracking-[0.15em] border border-ink/25 py-3 hover:bg-ink hover:text-paper transition">
              <Icon name="chat" size={14} /> Спросить
            </a>
          </div>

          {/* Accordions */}
          <div className="border-t border-ink/15">
            {[
              { k: "desc", title: "Описание", content: product.description },
              { k: "mat", title: "Состав и материал", content: `${product.material} · ${product.season} · ${product.fit} крой` },
              { k: "care", title: "Уход", content: product.care.join(" · ") },
              { k: "del", title: "Доставка и возврат", content: "Курьер по Москве и СПб — 1 день, по России — 2–3 дня. Бесплатно при заказе от 10 000 ₽. Возврат — 14 дней." },
            ].map((s) => (
              <div key={s.k} className="border-b border-ink/15">
                <button onClick={() => toggleS(s.k)} className="w-full flex items-center justify-between py-5 text-sm uppercase tracking-[0.18em]">
                  {s.title}
                  <Icon name={openSection === s.k ? "minus" : "plus"} size={16} />
                </button>
                {openSection === s.k && <div className="pb-5 text-ash leading-relaxed text-[15px]">{s.content}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* С ЧЕМ НОСИТЬ */}
      {pairsProducts.length > 0 && (
        <section className="bg-cream">
          <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-16">
            <p className="text-xs uppercase tracking-[0.3em] text-ash mb-3">С чем носить</p>
            <h2 className="font-display text-3xl lg:text-4xl mb-10">Собери образ</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Current product */}
              <div className="border-2 border-accent p-3 bg-paper">
                <img src={product.images[0]} className="w-full aspect-[3/4] object-cover mb-3" alt="" />
                <p className="text-sm font-medium">{product.name}</p>
                <p className="text-sm text-accent">{product.price.toLocaleString("ru")} ₽</p>
              </div>
              {pairsProducts.map((p) => (
                <button key={p.id} onClick={() => navigate({ name: "product", id: p.id })} className="text-left group">
                  <img src={p.images[0]} className="w-full aspect-[3/4] object-cover mb-3 zoom-img" alt="" />
                  <p className="text-sm font-medium group-hover:underline">{p.name}</p>
                  <p className="text-sm text-ash">{p.price.toLocaleString("ru")} ₽</p>
                </button>
              ))}
            </div>
            <div className="mt-6 text-right text-sm text-ash">
              Комплект · {(product.price + pairsProducts.reduce((a, p) => a + p.price, 0)).toLocaleString("ru")} ₽
            </div>
          </div>
        </section>
      )}

      {/* PRODUCT REVIEWS */}
      <Section eyebrow="Отзывы на этот товар">
        <div className="grid md:grid-cols-2 gap-6 max-w-3xl">
          {REVIEWS.slice(0, 2).map((r, i) => (
            <div key={i} className="border border-ink/15 p-6">
              <div className="flex items-center gap-0.5 text-accent-2 mb-3">
                {Array.from({ length: r.rating }).map((_, j) => <Icon key={j} name="star" size={14} />)}
              </div>
              <p className="text-[15px] leading-relaxed mb-4">«{r.text}»</p>
              <div className="text-xs uppercase tracking-[0.18em] text-ash">{r.name} · {r.city}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* RECOMMENDED */}
      {recs.length > 0 && (
        <Section eyebrow="Похожие товары" title="Может подойти">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10 lg:gap-x-6">
            {recs.map((p) => (
              <ProductCard key={p.id} product={p}
                onOpen={() => navigate({ name: "product", id: p.id })}
                onToggleFav={() => toggleFav(p.id)}
                isFav={favs.includes(p.id)}
              />
            ))}
          </div>
        </Section>
      )}

      {/* Quick order modal */}
      {quickOrder && (
        <QuickOrderModal product={product}
          onClose={() => setQuickOrder(false)}
          onSubmitData={(data) => { void Repo.saveFormSubmission("quick-order", data); }}
          onSuccess={() => { setQuickOrder(false); showToast("Заявка принята! Перезвоним через 15 минут."); }}
        />
      )}

      {/* Size help modal */}
      {sizeHelp && (
        <FormModal
          title="Подобрать размер"
          subtitle="Укажите ваши параметры — поможем выбрать идеальный размер за 15 минут."
          fields={[
            { name: "name", label: "Имя", required: true },
            { name: "phone", label: "Телефон или Telegram", type: "tel", required: true },
            { name: "height", label: "Рост (см)", type: "number" },
            { name: "weight", label: "Вес (кг)", type: "number" },
            { name: "chest", label: "Обхват груди (см)", type: "number" },
            { name: "fit", label: "Как любите носить?", options: ["По фигуре", "Свободнее", "Оверсайз"] },
          ]}
          onClose={() => setSizeHelp(false)}
          onSubmitData={(data) => { void Repo.saveFormSubmission("size-help", data); }}
          onSuccess={() => { setSizeHelp(false); showToast("Запрос отправлен! Ответим в течение 15 минут."); }}
          submitLabel="Узнать мой размер"
        />
      )}

      {/* Notify when in stock */}
      {notifyForm && (
        <FormModal
          title="Сообщить о наличии"
          subtitle={`Оставьте контакт — напишем, когда «${product.name}» в цвете ${product.colors[selectedColor]?.name} появится.`}
          fields={[
            { name: "phone", label: "Телефон или Telegram", type: "tel", required: true },
            { name: "email", label: "Или E-mail", type: "email" },
          ]}
          onClose={() => setNotifyForm(false)}
          onSubmitData={(data) => { void Repo.saveFormSubmission("notify", { ...data, product: product.name, color: product.colors[selectedColor]?.name || "" }); }}
          onSuccess={() => { setNotifyForm(false); showToast("Готово! Сообщим, когда товар появится."); }}
          submitLabel="Уведомить меня"
        />
      )}

      {/* Gift wrapping form */}
      {giftForm && (
        <FormModal
          title="Оформить как подарок"
          subtitle="Упакуем в фирменную коробку, добавим открытку с вашим текстом."
          fields={[
            { name: "name", label: "Ваше имя", required: true },
            { name: "phone", label: "Телефон", type: "tel", required: true },
            { name: "recipient", label: "Имя получателя" },
            { name: "message", label: "Текст на открытке (до 100 символов)", textarea: true },
            { name: "date", label: "Когда нужен подарок?", options: ["Как можно скорее", "Через 2–3 дня", "К конкретной дате"] },
          ]}
          onClose={() => setGiftForm(false)}
          onSubmitData={(data) => { void Repo.saveFormSubmission("gift", { ...data, product: product.name }); }}
          onSuccess={() => { setGiftForm(false); showToast("Отлично! Менеджер свяжется для уточнения деталей."); }}
          submitLabel="Заказать подарок"
        />
      )}
    </>
  );
}

/* =================== CART =================== */
export function CartPage({ navigate, cart, updateQty, removeFromCart }: Ctx) {
  const items = cart.map((it) => ({ ...it, product: PRODUCTS.find((p) => p.id === it.id)! })).filter((x) => x.product);
  const subtotal = items.reduce((a, x) => a + x.product.price * x.qty, 0);
  const shipping = subtotal === 0 ? 0 : subtotal >= 10000 ? 0 : 490;
  const total = subtotal + shipping;

  return (
    <Section eyebrow="Корзина" title={`Ваш заказ · ${items.length}`}>
      {items.length === 0 ? (
        <div className="py-24 text-center">
          <p className="text-ash mb-6">В корзине пока пусто.</p>
          <Btn onClick={() => navigate({ name: "catalog" })}>В каталог</Btn>
        </div>
      ) : (
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 divide-y divide-ink/10 border-y border-ink/10">
            {items.map((it) => (
              <div key={it.id + it.size} className="py-6 flex gap-4 lg:gap-6 items-start">
                <button onClick={() => navigate({ name: "product", id: it.id })} className="w-24 lg:w-32 aspect-[3/4] bg-cream overflow-hidden shrink-0">
                  <img src={it.product.images[0]} className="w-full h-full object-cover" alt="" />
                </button>
                <div className="flex-1 min-w-0">
                  <button onClick={() => navigate({ name: "product", id: it.id })} className="text-base lg:text-lg font-medium hover:underline text-left">
                    {it.product.name}
                  </button>
                  <div className="text-xs text-ash uppercase tracking-[0.18em] mt-2">
                    Размер {it.size} · {it.product.material.split(",")[0]}
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center border border-ink/20">
                      <button onClick={() => updateQty(it.id, it.size, Math.max(1, it.qty - 1))} className="w-9 h-9 flex items-center justify-center">
                        <Icon name="minus" size={14} />
                      </button>
                      <span className="w-9 text-center text-sm">{it.qty}</span>
                      <button onClick={() => updateQty(it.id, it.size, it.qty + 1)} className="w-9 h-9 flex items-center justify-center">
                        <Icon name="plus" size={14} />
                      </button>
                    </div>
                    <div className="font-semibold">{(it.product.price * it.qty).toLocaleString("ru")} ₽</div>
                  </div>
                </div>
                <button onClick={() => removeFromCart(it.id, it.size)} aria-label="Удалить" className="text-ash hover:text-ink">
                  <Icon name="close" size={18} />
                </button>
              </div>
            ))}
          </div>
          <div className="lg:col-span-4 lg:sticky lg:top-28 self-start bg-cream p-6 lg:p-8">
            <p className="text-xs uppercase tracking-[0.3em] mb-5">Итого</p>
            <Row label="Товары" value={`${subtotal.toLocaleString("ru")} ₽`} />
            <Row label="Доставка" value={shipping === 0 ? "Бесплатно" : `${shipping} ₽`} />
            <div className="border-t border-ink/15 my-4" />
            <Row label="К оплате" value={`${total.toLocaleString("ru")} ₽`} big />
            <div className="mt-6 space-y-3">
              <Btn full onClick={() => navigate({ name: "checkout" })}>Оформить заказ</Btn>
              <button onClick={() => navigate({ name: "catalog" })} className="w-full text-xs uppercase tracking-[0.25em] py-2 hover:text-accent">
                ← Продолжить покупки
              </button>
            </div>
            {subtotal < 10000 && (
              <p className="text-xs text-ash mt-5">
                Доберите ещё {(10000 - subtotal).toLocaleString("ru")} ₽ — доставка бесплатно.
              </p>
            )}
          </div>
        </div>
      )}
    </Section>
  );
}

function Row({ label, value, big = false }: { label: string; value: string; big?: boolean }) {
  return (
    <div className={`flex justify-between py-1 ${big ? "text-lg font-semibold" : "text-sm"}`}>
      <span className={big ? "" : "text-ash"}>{label}</span>
      <span>{value}</span>
    </div>
  );
}

/* =================== FAVORITES =================== */
export function FavoritesPage({ navigate, favs, toggleFav }: Ctx) {
  const items = PRODUCTS.filter((p) => favs.includes(p.id));
  return (
    <Section eyebrow="Избранное" title={`Сохранено · ${items.length}`}>
      {items.length === 0 ? (
        <div className="py-24 text-center">
          <p className="text-ash mb-6">Здесь будут вещи, которые вы сохраните.</p>
          <Btn onClick={() => navigate({ name: "catalog" })}>В каталог</Btn>
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10 lg:gap-x-6">
          {items.map((p) => (
            <ProductCard key={p.id} product={p}
              onOpen={() => navigate({ name: "product", id: p.id })}
              onToggleFav={() => toggleFav(p.id)}
              isFav={true}
            />
          ))}
        </div>
      )}
    </Section>
  );
}

/* =================== ABOUT =================== */
export function AboutPage({ navigate }: Ctx) {
  return (
    <>
      <section className="bg-ink text-paper">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-20 lg:py-32 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-paper/50 mb-4">О бренде</p>
            <h1 className="font-display text-5xl lg:text-7xl leading-[0.95] mb-6">
              Одежда без шума. <em className="text-accent-2">С характером.</em>
            </h1>
            <p className="text-paper/70 text-lg leading-relaxed max-w-xl">
              NEMKA — российский бренд мужской одежды. Мы делаем вещи, в которых не нужно ничего доказывать. Простая геометрия, плотные ткани, точная посадка.
            </p>
          </div>
          <img src={HERO_IMAGES.profile} alt="" className="aspect-[4/5] w-full object-cover" />
        </div>
      </section>
      <Section eyebrow="Принципы" title="На чём стоим">
        <div className="grid md:grid-cols-3 gap-10">
          {[
            { t: "Материал решает", d: "Шерсть, плотный хлопок, кожа. Никаких сомнительных смесей." },
            { t: "Посадка ≠ мода", d: "Лекала отшиваем и проверяем на людях разной комплекции." },
            { t: "Носите долго", d: "Спокойная палитра и геометрия, которые не устаревают." },
          ].map((b, i) => (
            <div key={i}>
              <div className="font-display text-3xl text-accent mb-3">0{i + 1}</div>
              <h3 className="text-lg uppercase tracking-[0.12em] mb-2">{b.t}</h3>
              <p className="text-ash leading-relaxed">{b.d}</p>
            </div>
          ))}
        </div>
      </Section>
      <section className="bg-cream">
        <div className="max-w-[1400px] mx-auto px-5 lg:px-10 py-20 grid lg:grid-cols-2 gap-12 items-center">
          <img src={HERO_IMAGES.suits} alt="" className="aspect-[4/3] w-full object-cover" />
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-ash mb-4">Производство</p>
            <h2 className="font-display text-4xl lg:text-5xl leading-tight mb-6">Где и как шьём</h2>
            <p className="text-ash leading-relaxed mb-4">
              Цех в Подмосковье, верх — на одной из старейших турецких фабрик. Каждая партия проходит ручную проверку качества.
            </p>
            <p className="text-ash leading-relaxed mb-6">
              Мы не делаем огромных коллекций — только то, что готовы носить сами.
            </p>
            <Btn variant="ghost" onClick={() => navigate({ name: "catalog" })}>Смотреть коллекцию</Btn>
          </div>
        </div>
      </section>
    </>
  );
}

/* =================== DELIVERY =================== */
export function DeliveryPage(_ctx: Ctx) {
  return (
    <Section eyebrow="Сервис" title="Доставка и оплата">
      <div className="grid lg:grid-cols-2 gap-10">
        <div className="space-y-8">
          <InfoBlock title="Доставка по Москве и СПб">Курьером в день заказа или на следующий — 390 ₽. Бесплатно при заказе от 10 000 ₽.</InfoBlock>
          <InfoBlock title="Доставка по России">СДЭК, Boxberry, Почта России. Срок — 2–5 дней. От 290 ₽.</InfoBlock>
          <InfoBlock title="Самовывоз">Из шоурума в Москве. Бесплатно. 11:00–21:00 ежедневно.</InfoBlock>
        </div>
        <div className="space-y-8">
          <InfoBlock title="Оплата онлайн">Картой Visa / MasterCard / МИР, СБП и Apple Pay.</InfoBlock>
          <InfoBlock title="Оплата при получении">Картой или наличными — курьером в Москве и СПб.</InfoBlock>
          <InfoBlock title="Возврат">14 дней с момента получения. Без объяснения причин. Возврат денег — 5 рабочих дней.</InfoBlock>
        </div>
      </div>
    </Section>
  );
}

function InfoBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border-l-2 border-accent pl-6 py-2">
      <h3 className="text-lg uppercase tracking-[0.15em] mb-2">{title}</h3>
      <p className="text-ash leading-relaxed">{children}</p>
    </div>
  );
}

/* =================== CONTACTS =================== */
type CField = { name: string; label: string; type?: string; required?: boolean; textarea?: boolean; options?: string[] };
type CFormCfg = { title: string; subtitle: string; fields: CField[]; btn: string };

export function ContactsPage({ showToast }: Ctx) {
  const [activeForm, setActiveForm] = useState<"feedback" | "size" | "style" | "wholesale">("feedback");
  const formConfigs: Record<string, CFormCfg> = {
    feedback: {
      title: "Обратная связь",
      subtitle: "Вопрос, пожелание, замечание — ответим в течение часа.",
      fields: [
        { name: "name", label: "Имя", required: true },
        { name: "phone", label: "Телефон", type: "tel", required: true },
        { name: "email", label: "E-mail", type: "email" },
        { name: "msg", label: "Сообщение", textarea: true, required: true },
      ],
      btn: "Отправить",
    },
    size: {
      title: "Подобрать размер",
      subtitle: "Поможем определить ваш размер по параметрам за 15 минут.",
      fields: [
        { name: "name", label: "Имя", required: true },
        { name: "phone", label: "Телефон или Telegram", type: "tel", required: true },
        { name: "height", label: "Рост (см)", type: "number" },
        { name: "weight", label: "Вес (кг)", type: "number" },
        { name: "chest", label: "Грудь (см)", type: "number" },
        { name: "fit", label: "Как любите носить?", options: ["По фигуре", "Свободнее", "Оверсайз"] },
      ],
      btn: "Узнать мой размер",
    },
    style: {
      title: "Консультация стилиста",
      subtitle: "Расскажите о себе — подберём комплект бесплатно.",
      fields: [
        { name: "name", label: "Имя", required: true },
        { name: "phone", label: "Телефон или Telegram", type: "tel", required: true },
        { name: "occasion", label: "Для какого случая?", options: ["Офис / деловой", "Повседневный", "Свидание / выход", "Подарок", "Другое"] },
        { name: "budget", label: "Бюджет", options: ["до 10 000 ₽", "10–30 000 ₽", "30–60 000 ₽", "без ограничений"] },
        { name: "comment", label: "Что ещё важно?", textarea: true },
      ],
      btn: "Получить рекомендацию",
    },
    wholesale: {
      title: "Оптовый запрос",
      subtitle: "Работаем с оптом от 30 единиц. Заполните форму — свяжемся за 24 часа.",
      fields: [
        { name: "company", label: "Компания", required: true },
        { name: "name2", label: "Контактное лицо", required: true },
        { name: "phone", label: "Телефон", type: "tel", required: true },
        { name: "email", label: "E-mail", type: "email", required: true },
        { name: "volume", label: "Примерный объём", options: ["30–100 единиц", "100–500 единиц", "500+ единиц"] },
        { name: "comment", label: "Комментарий", textarea: true },
      ],
      btn: "Отправить запрос",
    },
  };

  const cfg = formConfigs[activeForm];

  return (
    <Section eyebrow="Контакты" title="Поговорим">
      <div className="grid lg:grid-cols-2 gap-12">
        {/* Left: info + messengers */}
        <div className="space-y-8">
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-ash mb-2">Шоурум</p>
            <p className="text-xl">Москва, ул. Большая Никитская, 24</p>
            <p className="text-ash">Ежедневно · 11:00 — 21:00</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-ash mb-2">Связь</p>
            <a href="tel:+74951234567" className="text-xl block hover:text-accent">+7 495 123-45-67</a>
            <a href="mailto:mahmudovv.14.00@gmail.com" className="text-xl block hover:text-accent">mahmudovv.14.00@gmail.com</a>
            <p className="text-xs text-ash mt-1">09:00–22:00, ежедневно · ответ за 15 мин</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-ash mb-3">Мессенджеры</p>
            <div className="flex gap-3">
              {[MESSENGERS.telegram, MESSENGERS.vk, MESSENGERS.max].map((m) => (
                <a key={m.name} href={m.url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 border border-ink rounded-full text-sm hover:bg-ink hover:text-paper transition">
                  <MessengerIcon name={m.icon} size={16} />
                  {m.name}
                </a>
              ))}
            </div>
          </div>
          <div className="bg-cream p-6">
            <p className="text-xs uppercase tracking-[0.25em] text-ash mb-2">Время ответа поддержки</p>
            <div className="grid grid-cols-3 gap-4 mt-3">
              {[
                { ch: "Telegram / VK / MAX", time: "~15 мин" },
                { ch: "Телефон", time: "Моментально" },
                { ch: "E-mail", time: "~1 час" },
              ].map((r) => (
                <div key={r.ch}>
                  <p className="text-lg font-semibold text-accent">{r.time}</p>
                  <p className="text-xs text-ash">{r.ch}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: form switcher */}
        <div className="bg-cream p-6 lg:p-8">
          <div className="flex flex-wrap gap-2 mb-6">
            {([
              { key: "feedback", label: "Обратная связь" },
              { key: "size", label: "Подбор размера" },
              { key: "style", label: "Стилист" },
              { key: "wholesale", label: "Опт" },
            ] as const).map((f) => (
              <button key={f.key} onClick={() => setActiveForm(f.key)}
                className={`px-3 py-1.5 text-xs uppercase tracking-[0.18em] border rounded-full transition ${
                  activeForm === f.key ? "bg-ink text-paper border-ink" : "border-ink/30 hover:border-ink"}`}>
                {f.label}
              </button>
            ))}
          </div>
          <p className="text-xs uppercase tracking-[0.3em] mb-1">{cfg.title}</p>
          <p className="text-sm text-ash mb-6">{cfg.subtitle}</p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.target as HTMLFormElement;
              const data = Object.fromEntries(new FormData(form).entries()) as Record<string, string>;
              const typeMap = {
                feedback: "feedback",
                size: "size-help",
                style: "style-consult",
                wholesale: "wholesale",
              } as const;
              void Repo.saveFormSubmission(typeMap[activeForm], data);
              const msgs: Record<string, string> = {
                feedback: "Спасибо! Ответим в течение часа.",
                size: "Запрос отправлен! Поможем с размером за 15 минут.",
                style: "Заявка принята! Стилист свяжется в течение часа.",
                wholesale: "Запрос отправлен! Менеджер свяжется в течение 24 часов.",
              };
              showToast(msgs[activeForm]);
              form.reset();
            }}
            className="space-y-4"
          >
            {cfg.fields.map((f) => (
              <label key={f.name} className="block">
                <span className="text-xs uppercase tracking-[0.2em] text-ash block mb-1.5">{f.label}</span>
                {f.textarea ? (
                  <textarea name={f.name} rows={3} required={f.required}
                    className="w-full bg-paper border border-ink/20 px-4 py-3 outline-none focus:border-ink" />
                ) : f.options ? (
                  <select name={f.name} required={f.required}
                    className="w-full bg-paper border border-ink/20 px-4 py-3 outline-none focus:border-ink">
                    <option value="">Выберите</option>
                    {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
                  </select>
                ) : (
                  <input type={f.type ?? "text"} name={f.name} required={f.required}
                    className="w-full bg-paper border border-ink/20 px-4 py-3 outline-none focus:border-ink" />
                )}
              </label>
            ))}
            <Btn type="submit" full>{cfg.btn}</Btn>
          </form>
        </div>
      </div>
    </Section>
  );
}

/* =================== LOOKBOOK =================== */
export function LookbookPage({ navigate }: Ctx) {
  const looks = [
    { name: "Look 01 · Ночной город", img: HERO_IMAGES.blackOutfit },
    { name: "Look 02 · Север", img: HERO_IMAGES.whiteJacket },
    { name: "Look 03 · Поле", img: HERO_IMAGES.corduroy },
    { name: "Look 04 · Студия", img: HERO_IMAGES.beige },
    { name: "Look 05 · Дорога", img: HERO_IMAGES.kurta },
    { name: "Look 06 · Утро", img: HERO_IMAGES.whiteOutdoor },
  ];
  return (
    <>
      <section className="max-w-[1400px] mx-auto px-5 lg:px-10 pt-12 pb-8">
        <p className="text-xs uppercase tracking-[0.3em] text-ash mb-3">Lookbook AW26</p>
        <h1 className="font-display text-5xl lg:text-7xl leading-[0.95] max-w-3xl">
          Шесть образов. <em className="text-accent">Один характер.</em>
        </h1>
      </section>
      <section className="max-w-[1400px] mx-auto px-5 lg:px-10 py-10 grid grid-cols-12 gap-3 lg:gap-5">
        {looks.map((l, i) => {
          const span = i % 5 === 0 ? "col-span-12 lg:col-span-7" : i % 5 === 1 ? "col-span-12 lg:col-span-5" : i % 5 === 2 ? "col-span-6 lg:col-span-4" : i % 5 === 3 ? "col-span-6 lg:col-span-4" : "col-span-12 lg:col-span-4";
          return (
            <div key={i} className={`${span} aspect-[4/5] relative overflow-hidden bg-cream`}>
              <img src={l.img} alt={l.name} className="w-full h-full object-cover zoom-img" />
              <div className="absolute bottom-4 left-4 text-paper text-xs uppercase tracking-[0.25em] bg-ink/70 px-3 py-1.5">{l.name}</div>
            </div>
          );
        })}
      </section>
      <div className="text-center pb-20">
        <Btn onClick={() => navigate({ name: "catalog" })}>Купить образы</Btn>
      </div>
    </>
  );
}

/* =================== FAQ =================== */
export function FaqPage(_ctx: Ctx) {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <Section eyebrow="Вопросы и ответы" title="FAQ">
      <div className="max-w-3xl mx-auto divide-y divide-ink/15 border-y border-ink/15">
        {FAQ.map((f, i) => (
          <div key={i}>
            <button onClick={() => setOpen(open === i ? null : i)}
              className="w-full flex justify-between items-center py-6 text-left text-base lg:text-lg">
              <span className="pr-4">{f.q}</span>
              <Icon name={open === i ? "minus" : "plus"} />
            </button>
            {open === i && <div className="pb-6 text-ash leading-relaxed">{f.a}</div>}
          </div>
        ))}
      </div>
      <div className="mt-16 text-center bg-cream p-10 rounded">
        <p className="text-xs uppercase tracking-[0.3em] text-ash mb-3">Не нашли ответ?</p>
        <h3 className="font-display text-2xl mb-4">Напишите нам — ответим за 15 минут</h3>
        <div className="flex justify-center gap-3">
          {[MESSENGERS.telegram, MESSENGERS.vk, MESSENGERS.max].map((m) => (
            <a key={m.name} href={m.url} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 border border-ink rounded-full text-sm hover:bg-ink hover:text-paper transition">
              <MessengerIcon name={m.icon} size={16} />
              {m.name}
            </a>
          ))}
        </div>
      </div>
    </Section>
  );
}

/* =================== CHECKOUT =================== */
export function CheckoutPage({ cart, navigate, showToast, user }: Ctx) {
  const items = cart.map((it) => ({ ...it, product: PRODUCTS.find((p) => p.id === it.id)! })).filter((x) => x.product);
  const subtotal = items.reduce((a, x) => a + x.product.price * x.qty, 0);
  const shipping = subtotal >= 10000 ? 0 : 490;
  const total = subtotal + shipping;
  const [done, setDone] = useState(false);

  if (items.length === 0 && !done) {
    return (
      <Section eyebrow="Оформление" title="Корзина пуста">
        <Btn onClick={() => navigate({ name: "catalog" })}>В каталог</Btn>
      </Section>
    );
  }

  if (done) {
    return (
      <Section eyebrow="Готово" title="Заказ принят">
        <p className="text-ash text-lg max-w-xl mb-8">
          Мы отправили подтверждение на вашу почту. Менеджер свяжется в течение часа.
        </p>
        <Btn onClick={() => navigate({ name: "home" })}>На главную</Btn>
      </Section>
    );
  }

  return (
    <Section eyebrow="Оформление" title="Один шаг до посылки">
      <form onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.target as HTMLFormElement);
            const orderItems = items.map(it => ({ productId: it.id, name: it.product.name, size: it.size, color: "", qty: it.qty, price: it.product.price }));
            void Repo.createOrder({
              userId: user?.id || "guest",
              items: orderItems,
              total,
              shipping,
              delivery: fd.get("del") as string || "Курьер",
              payment: fd.get("pay") as string || "Картой",
              comment: fd.get("comment") as string || "",
              name: fd.get("name") as string || "",
              phone: fd.get("phone") as string || "",
              email: fd.get("email") as string || "",
              city: fd.get("city") as string || "",
              address: fd.get("address") as string || "",
            });
            setDone(true);
            showToast("Заказ оформлен и сохранён в базу данных!");
          }}
        className="grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-8 space-y-8">
          <div>
            <p className="text-xs uppercase tracking-[0.25em] mb-4">Контакты</p>
            <div className="grid sm:grid-cols-2 gap-4">
              <FormField name="name" label="Имя" required />
              <FormField name="phone" label="Телефон" type="tel" required />
              <FormField name="email" label="E-mail" type="email" required />
              <FormField name="city" label="Город" required />
            </div>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] mb-4">Доставка</p>
            <div className="space-y-2">
              {["Курьер до двери", "Пункт выдачи СДЭК", "Boxberry", "Самовывоз из шоурума"].map((d) => (
                <label key={d} className="flex items-center gap-3 border border-ink/15 px-4 py-3 cursor-pointer hover:border-ink">
                  <input type="radio" name="del" defaultChecked={d === "Курьер до двери"} className="accent-[var(--color-accent)]" />
                  <span>{d}</span>
                </label>
              ))}
            </div>
            <div className="mt-4"><FormField name="address" label="Адрес доставки" required /></div>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.25em] mb-4">Оплата</p>
            <div className="space-y-2">
              {["Картой онлайн", "СБП", "При получении"].map((d) => (
                <label key={d} className="flex items-center gap-3 border border-ink/15 px-4 py-3 cursor-pointer hover:border-ink">
                  <input type="radio" name="pay" defaultChecked={d === "Картой онлайн"} className="accent-[var(--color-accent)]" />
                  <span>{d}</span>
                </label>
              ))}
            </div>
          </div>
          <FormField name="comment" label="Комментарий к заказу" textarea />
        </div>
        <div className="lg:col-span-4 lg:sticky lg:top-28 self-start bg-cream p-6 lg:p-8">
          <p className="text-xs uppercase tracking-[0.3em] mb-5">Ваш заказ</p>
          <div className="space-y-3 mb-5 max-h-72 overflow-auto">
            {items.map((it) => (
              <div key={it.id + it.size} className="flex gap-3">
                <img src={it.product.images[0]} className="w-14 h-16 object-cover" alt="" />
                <div className="flex-1 text-sm">
                  <div>{it.product.name}</div>
                  <div className="text-ash text-xs">{it.size} · {it.qty} шт.</div>
                </div>
                <div className="text-sm font-semibold">{(it.product.price * it.qty).toLocaleString("ru")} ₽</div>
              </div>
            ))}
          </div>
          <Row label="Товары" value={`${subtotal.toLocaleString("ru")} ₽`} />
          <Row label="Доставка" value={shipping === 0 ? "Бесплатно" : `${shipping} ₽`} />
          <div className="border-t border-ink/15 my-3" />
          <Row label="К оплате" value={`${total.toLocaleString("ru")} ₽`} big />
          <div className="mt-6"><Btn full type="submit">Подтвердить заказ</Btn></div>
          <p className="text-xs text-ash mt-4 text-center">
            Нажимая «Подтвердить», вы соглашаетесь с политикой конфиденциальности.
          </p>
        </div>
      </form>
    </Section>
  );
}

function FormField({ name, label, type = "text", required = false, textarea = false }: { name?: string; label: string; type?: string; required?: boolean; textarea?: boolean }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-[0.2em] text-ash block mb-2">{label}</span>
      {textarea ? (
        <textarea name={name} rows={3} required={required} className="w-full bg-paper border border-ink/20 px-4 py-3 outline-none focus:border-ink" />
      ) : (
        <input name={name} type={type} required={required} className="w-full bg-paper border border-ink/20 px-4 py-3 outline-none focus:border-ink" />
      )}
    </label>
  );
}

/* =================== SIZE GUIDE =================== */
export function SizeGuidePage(_ctx: Ctx) {
  const rows = [
    ["XS", "44", "86", "70", "92"],
    ["S", "46", "90", "74", "96"],
    ["M", "48", "94", "78", "100"],
    ["L", "50", "98", "82", "104"],
    ["XL", "52", "104", "88", "110"],
    ["XXL", "54", "110", "94", "116"],
  ];
  return (
    <Section eyebrow="Размеры" title="Размерная сетка">
      <p className="text-ash max-w-2xl mb-10">
        Размер указан для верхней одежды и трикотажа. Если сомневаетесь — напишите в чат, поможем за 15 минут.
      </p>
      <div className="overflow-x-auto border border-ink/15">
        <table className="w-full text-left text-sm">
          <thead className="bg-cream">
            <tr>
              {["Размер", "RU", "Грудь (см)", "Талия (см)", "Бёдра (см)"].map((h) => (
                <th key={h} className="px-5 py-4 uppercase tracking-[0.15em] text-xs">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-t border-ink/10">
                {r.map((c, j) => <td key={j} className="px-5 py-4">{c}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-10 flex flex-wrap gap-3 items-center">
        <span className="text-sm text-ash">Не уверены в размере?</span>
        {[MESSENGERS.telegram, MESSENGERS.vk].map((m) => (
          <a key={m.name} href={m.url} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 border border-ink rounded-full text-sm hover:bg-ink hover:text-paper transition">
            <MessengerIcon name={m.icon} size={14} />
            Написать в {m.name}
          </a>
        ))}
      </div>
    </Section>
  );
}
